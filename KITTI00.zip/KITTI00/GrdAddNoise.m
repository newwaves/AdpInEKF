%--------------------------------------------------------------------------
%   Added noises to groundtruth, in Lie Group.
%--------------------------------------------------------------------------

clear all;close all;clc;
A = load('GrdTruth.mat');    % 2020-09-25
PoseHDL = A.vTestTFNew;     % 2020-09-25
SelRange = A.vIdxTest;
Len = size(PoseHDL,3);

% Motion noise covariance is [];% [ax, ay, az, x, y, z]
% StdD = [pi/3000, pi/3000, pi/450, 0.01, 0.01, 0.001 ];
StdD = [0.01, 0.01, 0.01, 0.01, 0.01, 0.01 ];
% Random variate from Gaussian mixture distribution
% random is a generic function that accepts a distribution by name. It is
% faster to use a more specialized function when possible, such as RANDN
% or NORMRND for the normal distribution.
%  random('Normal', mu, std, Len,1); % 2020-04-26 @Home
vNoise = [  random('Normal', 0.0, StdD(1),Len,1),...
            random('Normal', 0.0, StdD(2),Len,1),...
            random('Normal', 0.0, StdD(3),Len,1),...
            random('Normal', 0.0, StdD(4),Len,1),...
            random('Normal', 0.0, StdD(5),Len,1),...
            random('Normal', 0.0, StdD(6),Len,1)];
OnLineV = var(vNoise);
vNewTF = zeros(4,4,Len);

NewTF = [PoseHDL(:,:,1);0 0 0 1];
vNewTF(:,:,1) = NewTF;
vNewTra = NewTF(1:3,end)';
CurTF = [PoseHDL(:,:,1);0 0 0 1];
vRawTra = CurTF(1:3,end)';
for i = 2 : 1 : Len
    PreTF = [PoseHDL(:,:,i-1);0 0 0 1];
    CurTF = [PoseHDL(:,:,i);0 0 0 1];
    DelTF = PreTF \ CurTF; % inv(PreTF) * CurTF;
    
    noiseR = expm(skew(vNoise(i,1:3)));
    noiseT = vNoise(i,4:6)'; % add noise to DeltaTF
    nsDTF = DelTF * [noiseR,noiseT; 0 0 0 1]; % T * Exp(epsilon)
    % nsDTF = [noiseR * DelTF(1:3,1:3), DelTF(1:3,1:3) * noiseT + DelTF(1:3,end); 0 0 0 1];
    % nsDTF = [DelTF(1:3,1:3) * noiseR, DelTF(1:3,1:3) * noiseT + DelTF(1:3,end); 0 0 0 1];

    NewTF = NewTF * nsDTF;
    vNewTF(:,:,i) = NewTF;
    vRawTra = [vRawTra; CurTF(1:3,end)'];
    vNewTra = [vNewTra; NewTF(1:3,end)'];
end
figure;hold on;grid on;axis equal;
plot3( vRawTra(:,1), vRawTra(:,2), vRawTra(:,3), 'k.-' );
plot3( vRawTra(1,1), vRawTra(1,2), vRawTra(1,3), 'rp' );
plot3( vRawTra(end,1), vRawTra(end,2), vRawTra(end,3), 'bp' );
plot3( vNewTra(:,1), vNewTra(:,2), vNewTra(:,3), 'ro-' );
plot3( vNewTra(1,1), vNewTra(1,2), vNewTra(1,3), 'rp' );
plot3( vNewTra(end,1), vNewTra(end,2), vNewTra(end,3), 'bp' );
