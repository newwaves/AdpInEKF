%--------------------------------------------------------------------------
% Read map and trajactory for displaying
%--------------------------------------------------------------------------
clc;close all;clear all;
SeqIdx = 0;
if SeqIdx == 6
    % Kitti06 MapInGpsTF and GpsInMapTF
    GpsInMap = [0.9999876250063414, 0.0049580413167479, 0.0004094636467686, 9.6564737150539397;-0.0049545698703912, 0.9999550533753707, -0.0080835305689352, -0.0596383400556560;-0.0004495237213058, 0.0080814018190484, 0.9999672439000504, 0.2346896742312143;0.0, 0.0, 0.0, 1.0];
    MapInGps = [0.9999876250063414, -0.0049545698703912, -0.0004495237213058, -9.6565442000000008;0.0049580413167479, 0.9999550533753707, 0.0080814018190484, 0.0098618423000000;0.0004094636467686, -0.0080835305689352, 0.9999672439000505, -0.2391180500000000;0.0, 0.0, 0.0, 1.0];
    GpsTf = [1,-5.69982952167452e-19,-1.85831501665082e-18,0;1.77426320336169e-19,1.00000000000000,2.03996074655630e-18,0;2.00340304420825e-19,-8.59989770922764e-19,1.00000000000000,0;0.0, 0.0, 0.0, 1.0];
else
    % Kitti00 MapInGpsTF and GpsInMapTF
    GpsInMap = [0.9979316405429378, 0.0618790318003254, 0.0174191339260843, -191.1038252824799315;-0.0610476737368593, 0.9971298576109864, -0.0447797788294212, 82.7802011287752180;-0.0201400678896204, 0.0436237605456960, 0.9988450055845769, 0.1180438643882286;0.0, 0.0, 0.0, 1.0];
    MapInGps = [0.9979316405429379, -0.0610476737368594, -0.0201400678896204, 195.7644699999999887;0.0618790318003254, 0.9971298576109865, 0.0436237605456960, -70.7224400000000060;0.0174191339260843, -0.0447797788294213, 0.9988450055845768, 6.9178347000000002;0.0, 0.0, 0.0, 1.0];
    GpsTf = [-0.402389747595476,-0.915006349506970,-0.0290855565527378,223.682434737812;0.914442444397202,-0.403239662360424,0.0345356515613210,-143.826169600598;-0.0433287933501027,-0.0127002646219991,0.998980069753769,9.80427142426403;0.0, 0.0, 0.0, 1.0];
end

RootDir = '..\pcMap';
MapName = fullfile(RootDir, 'HDMap.pcd');  %   read map
ptMap = pcread( MapName );                 %   read map
figure;hold on;grid on;box on;
pcshow(ptMap);
view(2);
%%
vRange = 1 : 556;
P = load('GrdTruth.mat'); % 2020-04-26
vGrdTF = P.vTestTF(:,:,vRange);
GrdPose = CvTF2vEul(vGrdTF);
Q = load('OdoPose.mat'); % 2020-10-31
OdoPose = CvTF2vEul(Q.vNewTF(:,:,vRange));

figure;hold on;grid on;FSize = 15;box on;axis equal;
set(gcf, 'color',[0.3,0.3,0.3]);
set(gca, 'color',[0.3,0.3,0.3]);
plot3(GrdPose(vRange,1),GrdPose(vRange,2),GrdPose(vRange,3),'k.-');
plot3(OdoPose(vRange,1),OdoPose(vRange,2),OdoPose(vRange,3),'b.-');
pcshow(ptMap);view(2)
H = legend({'GrdTruth','OdoPose','Map'}, 'FontSize', FSize);
set(H, 'Color','w');
%%
figure;hold on;grid on;FSize = 18;box on;axis equal;
set(gcf, 'color',[1,1,1]);
plot3(GrdPose(vRange,1),GrdPose(vRange,2),GrdPose(vRange,3),'r.-','MarkerSize',5, 'LineWidth', 3);
plot3(OdoPose(vRange,1),OdoPose(vRange,2),OdoPose(vRange,3),'b.-','MarkerSize',5, 'LineWidth', 3);
pcshow(ptMap);view(2)
legend({'GrdTruth','ImuPose'}, 'FontSize', FSize, 'TextColor', 'w');