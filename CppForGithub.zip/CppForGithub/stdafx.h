// stdafx.h : ��׼ϵͳ�����ļ��İ����ļ���
// ���Ǿ���ʹ�õ��������ĵ�
// �ض�����Ŀ�İ����ļ�
//

#pragma once
#define WIN32_LEAN_AND_MEAN		// �� Windows ͷ���ų�����ʹ�õ�����

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <cstdlib>
#include <cstdio>
#include <cmath>

//#define NOMINMAX
#include <windows.h>

#include <process.h>
#include <direct.h>
#include "iomanip"
#include <io.h>
#include <time.h>
#include <cstring>
#include <sstream>
#include <iostream>
#include <fstream> 

#include <vector>
#include <stack>
#include <string>
#include <set>
#include <map>
#include <bitset>
#include <Algorithm>
#include <numeric>
#include <omp.h>


#include <stdio.h>
#include <tchar.h>
#include <direct.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <time.h>
#include <random>

//#ifdef _DEBUG
//#pragma  comment( lib, "opencv_calib3d2413d.lib" )
//#pragma  comment( lib, "opencv_contrib2413d.lib" )
//#pragma  comment( lib, "opencv_core2413d.lib" )
//#pragma  comment( lib, "opencv_features2d2413d.lib" )
//#pragma  comment( lib, "opencv_flann2413d.lib" )
//#pragma  comment( lib, "opencv_gpu2413d.lib" )
//#pragma  comment( lib, "opencv_highgui2413d.lib" )
//#pragma  comment( lib, "opencv_imgproc2413d.lib" )
//#pragma  comment( lib, "opencv_legacy2413d.lib" )
//#pragma  comment( lib, "opencv_ml2413d.lib" )
//#pragma  comment( lib, "opencv_objdetect2413d.lib" )
//#pragma  comment( lib, "opencv_ts2413d.lib" )
//#pragma  comment( lib, "opencv_video2413d.lib" )
//#else
//#pragma  comment( lib, "opencv_calib3d2413.lib" )
//#pragma  comment( lib, "opencv_contrib2413.lib" )
//#pragma  comment( lib, "opencv_core2413.lib" )
//#pragma  comment( lib, "opencv_features2d2413.lib" )
//#pragma  comment( lib, "opencv_flann2413.lib" )
//#pragma  comment( lib, "opencv_gpu2413.lib" )
//#pragma  comment( lib, "opencv_highgui2413.lib" )
//#pragma  comment( lib, "opencv_imgproc2413.lib" )
//#pragma  comment( lib, "opencv_legacy2413.lib" )
//#pragma  comment( lib, "opencv_ml2413.lib" )
//#pragma  comment( lib, "opencv_objdetect2413.lib" )
//#pragma  comment( lib, "opencv_ts2413.lib" )
//#pragma  comment( lib, "opencv_video2413.lib" )
//#endif

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/filters/filter.h>
#include <pcl/visualization/pcl_visualizer.h>

#include <pcl/search/kdtree.h>
#include <pcl/search/search.h>

#include <pcl/registration/gicp.h>
#include <pcl/registration/ndt.h>      //NDT(��̬�ֲ�)��׼��ͷ�ļ�
#include <pcl/registration/icp.h>
#include <pcl/registration/transformation_estimation_point_to_plane_lls.h>
#include <pcl/registration/icp_nl.h>
#include <pcl/registration/transforms.h>
#include <pcl/filters/approximate_voxel_grid.h>   
#include <pcl/filters/voxel_grid.h>

#include "pcl\common\centroid.h"
#include "pcl\common\impl\centroid.hpp"

//// Eigen. 
#include <Eigen/src/Core/DenseBase.h>
#include <Eigen/src/Geometry/Transform.h>
#include <Eigen/src/Geometry/EulerAngles.h>
#include <Eigen/src/Geometry/Quaternion.h>
#include <Eigen/src/Geometry/AngleAxis.h>
#include <Eigen/src/LU\FullPivLU.h>
#include <Eigen/src/LU/Determinant.h>
#include <Eigen/src/LU/InverseImpl.h>
#include <Eigen/src/LU/PartialPivLU.h>

//

//#include <opencv2/opencv.hpp>
//#include <opencv2/opencv_modules.hpp>


// TODO:  �ڴ˴����ó�����Ҫ������ͷ�ļ�
using namespace std;

#include <winsock2.h>
#pragma comment(lib,"WS2_32")

#define WIN32_LEAN_AND_MEAN		// �� Windows ͷ���ų�����ʹ�õ�����
#include "targetver.h"



typedef Eigen::Matrix< double, Eigen::Dynamic, Eigen::Dynamic> MatXX;
typedef Eigen::Matrix< double, 4, Eigen::Dynamic> Vec4X;
typedef Eigen::Matrix< double, 3, Eigen::Dynamic> Vec3X;
typedef Eigen::Matrix< double, 1, Eigen::Dynamic> Vec1X;
typedef Eigen::Matrix< double, 6, 1> Vec6d;
typedef Eigen::Matrix< double, 3, 1> Vec3d;
typedef Eigen::Matrix< double, 4, 1> Vec4d;
typedef Eigen::Matrix< double, 6, 6> Mat6d;
typedef Eigen::Matrix< double, 3, 6> Mat36;
typedef Eigen::Matrix< double, 6, 3> Mat63;
typedef Eigen::Matrix< double, 3, 3> Mat3d;
typedef Eigen::Matrix< double, 4, 4> Mat4d;

