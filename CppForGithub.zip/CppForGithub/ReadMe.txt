

An Adaptive Invariant EKF for Localization Using 3D Point Cloud

----------------------------------------------------------------------------
Input : 
	3D point cloud map 	- location and normals
	the current lidar scans	- location 
	odometry pose (can be replaced by IMU information) - represented by SE(3)

Output:
	the current pose 			- represented by SE(3)
	the uncertainty of the current pose 	- covariance matrix (6 X 6)

----------------------------------------------------------------------------
Cpp code:

The code depends on the PCL 1.8.1 library, and the test is successful in the VS2015 environment.

The test data is KITTI.

In order to make the program run successfully, the correct path of the KITTI dataset needs to be modified before use.

----------------------------------------------------------------------------
Matlab code:

All codes are tested successfully in Matlab R2020a.
----------------------------------------------------------------------------

Enjoy and good luck!

----------------------------------------------------------------------------

Email - newwaves@163.com




