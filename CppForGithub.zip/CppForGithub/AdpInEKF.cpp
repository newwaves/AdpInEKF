// AdpInEKF.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"


#include "stdafx.h"
#include "AdpParams.h"	//	std::vector<sCov>
#include "AdpInEKF.h"

#include <Eigen/Dense>

int main()
{
	clock_t time_stt = clock(); // ��ʱ
	CAdpInEKF myLoc;
	//myLoc.setLogDir(DataRoot);
	//std::vector<int> vC = {1, 10, 50, 100, 200, 500, 1000};
	myLoc.setLogDir();

	myLoc.ProcessShow();


	return 0;
}


