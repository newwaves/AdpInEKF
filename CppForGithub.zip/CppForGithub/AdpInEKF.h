#pragma once
#ifndef H_ADP_EKF_H
#define H_ADP_EKF_H

#include "stdafx.h"
#include "LocComFun.h"
#include "AdpParams.h"


//---------------------------------------------------------------------------
//	
//---------------------------------------------------------------------------
class CAdpInEKF
{
private:
	CLocPara m_Para;
	int m_nFrm;
	// Aom EKF Alg
	Vec6d m_PoseK;		// x, y, z, az, ay, ax
	Vec6d m_StateK;		// ax, ay, az, x, y, z
	Mat4d m_TFK;		// m_TF = [m_R,m_t; 0 0 0 1];
	Mat4d m_TFK_1;
	Mat4d m_ErrorTF;
	Mat6d m_CovK;
	Mat6d m_CovK_1;
	Mat6d m_Mk;			// Motion covariance
	Mat3d m_Qk;			// Observation covariance
	std::vector<Vec6d> m_vLocPose;	//	save m_PoseK;
	std::vector<Vec6d> m_vImuPose;	//	Get pose
	std::vector<Vec4d> m_vLogInfo;
	double m_FitScore;				//	evaluate

	pcl::PointCloud<pcl::PointXYZ>::Ptr			m_MapP_ptr;		//	
	pcl::search::KdTree<pcl::PointXYZ>::Ptr		m_KdMapP_ptr;	//	calculating the score	
	pcl::PointCloud<pcl::PointNormal>::Ptr		m_MapPN_ptr;	//	
	pcl::search::KdTree<pcl::PointNormal>::Ptr	m_KdMapPN_ptr;	//	computer match

	pcl::registration::CorrespondenceEstimation<pcl::PointXYZ, pcl::PointXYZ> m_Correspond;

	pcl::PointCloud<pcl::PointXYZ>::Ptr m_InaHdl_ptr;	// Raw input pointcloud
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_EKFHdl_ptr;	// for updating the state
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_RegHdl_ptr;	// for registration about 3000 points
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_OutHdl_ptr;	// 	
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_FitHdl_ptr;	// for fitscorefun() and GeneTrain()
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_OutTra_ptr;

	//	Registration method
	pcl::IterativeClosestPoint<pcl::PointNormal, pcl::PointNormal> m_P2PlMatcher;
	pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> m_P2PICP;
	pcl::IterativeClosestPointNonLinear<pcl::PointNormal, pcl::PointNormal> m_P2PluLM; // Levenberg-Marquardt
	pcl::NormalDistributionsTransform<pcl::PointXYZ, pcl::PointXYZ> m_Ndt;
	//pcl::GeneralizedIterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> m_Gicp;

	////	save log
	//std::ofstream m_LocInfoLog;
	////	DataRoot
	std::string m_FilePre;
	std::string m_MapRoot;
	std::string m_HdlRoot;
	std::string m_LogDir;

	// display
	pcl::visualization::PCLVisualizer m_Viewer;
	std::string m_DisInfo;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_pGpsPose;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_pLocPose;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_GpsShow_ptr;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_ImuShow_ptr;
	pcl::PointCloud<pcl::PointNormal>::Ptr m_MapShow_ptr;	//
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_InaShow_ptr;
	pcl::PointCloud<pcl::PointXYZ>::Ptr m_TraShow_ptr;
	//-------------------------------------------------------------------------

public:
	CAdpInEKF() {
		m_nFrm = m_Para.m_StartID;
		m_TFK_1 = m_Para.m_StartTF;
		m_CovK_1 = m_Para.m_InitCov.asDiagonal();
		m_ErrorTF = Eigen::Matrix4d::Identity();
		m_TFK = m_TFK_1;				// m_TF = [m_R,m_t; 0 0 0 1];
		m_CovK = m_CovK_1;
		m_StateK = CTF2State(m_TFK);			// ax, ay, az, x, y, z
		m_PoseK = CTF2Pose(m_TFK);				// x, y, z, az, ay, ax
		m_Mk = m_Para.m_MotionCov.asDiagonal();
		m_Qk = Mat3d::Identity();

		m_vImuPose.clear();
		m_vLocPose.clear();
		m_vLogInfo.clear();
		m_FitScore = 0.0;
		if (m_Para.m_isUseDataRoot == 1) // 1 - Using out HDL .bin file
		{
			m_HdlRoot = m_Para.m_DataRoot;
		}
		else    // 0 - Using pcd file directly
		{
			m_HdlRoot = m_Para.m_PcdRoot;
		}
		m_MapRoot = m_Para.m_MapRoot;
		//
		pcl::PointCloud<pcl::PointNormal>::Ptr temp1(new pcl::PointCloud<pcl::PointNormal>);
		m_MapPN_ptr = temp1;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp2(new pcl::PointCloud<pcl::PointXYZ>);
		m_MapP_ptr = temp2;
		//	living data 
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp3(new pcl::PointCloud<pcl::PointXYZ>);
		m_InaHdl_ptr = temp3; // pcl type
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp4(new pcl::PointCloud<pcl::PointXYZ>);
		m_EKFHdl_ptr = temp4;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp5(new pcl::PointCloud<pcl::PointXYZ>);
		m_RegHdl_ptr = temp5;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp6(new pcl::PointCloud<pcl::PointXYZ>);
		m_OutHdl_ptr = temp6;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp7(new pcl::PointCloud<pcl::PointXYZ>);
		m_OutTra_ptr = temp7;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp8(new pcl::PointCloud<pcl::PointXYZ>);
		m_FitHdl_ptr = temp8;
		m_FitScore = 0.0;
		//OpenLogFile();	//	save localization log	save receive pose	save send pose	
		std::cout << "Load map need more time(about 4s), please hold on ...... " << std::endl;
		LoadFullMap();	//	Load Full Map
		std::cout << "Configing scan matcher ...... " << std::endl;
		ConfigMatcher();
		m_Correspond.setInputTarget(m_MapP_ptr);
		m_Correspond.setSearchMethodTarget(m_KdMapP_ptr);

		//  display
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp11(new pcl::PointCloud<pcl::PointXYZ>);
		m_pGpsPose = temp11;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp12(new pcl::PointCloud<pcl::PointXYZ>);
		m_pLocPose = temp12;
		pcl::PointCloud<pcl::PointNormal>::Ptr temp13(new pcl::PointCloud<pcl::PointNormal>);
		m_MapShow_ptr = temp13;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp14(new pcl::PointCloud<pcl::PointXYZ>);
		m_GpsShow_ptr = temp14;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp15(new pcl::PointCloud<pcl::PointXYZ>);
		m_ImuShow_ptr = temp15;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp16(new pcl::PointCloud<pcl::PointXYZ>);
		m_InaShow_ptr = temp16;
		pcl::PointCloud<pcl::PointXYZ>::Ptr temp17(new pcl::PointCloud<pcl::PointXYZ>);
		m_TraShow_ptr = temp17;

		m_DisInfo = "\0";
		InitViewer();

	}
	void setLogDir()
	{
		SYSTEMTIME tStart;      // create file root
		GetLocalTime(&tStart);
		char tmpFolder[200] = "D:\\3DLidarRecord\\";
		if (0 != _access(tmpFolder, 0))
		{
			_mkdir(tmpFolder);
		}
		sprintf(tmpFolder, "%s3DLidar\\", tmpFolder);
		if (0 != _access(tmpFolder, 0))
		{
			_mkdir(tmpFolder);
		}
		sprintf(tmpFolder, "%s%04d_%02d_%02d\\", tmpFolder, tStart.wYear, tStart.wMonth, tStart.wDay);
		if (_access(tmpFolder, 0) != 0)
		{
			if (_mkdir(tmpFolder))
			{
				std::cout << "Error: Output Folder is not Created!\n";
				exit(-1);
			}
		}
		char g_LidarFolder[200];
		sprintf(g_LidarFolder, "%sRecord_%4d_%02d_%02d_%02d_%02d_%02d", tmpFolder, tStart.wYear, tStart.wMonth, tStart.wDay,
			tStart.wHour, tStart.wMinute, tStart.wSecond);

		char tmpStr[500] = "\0";
		if (m_Para.m_isAdp == 1)
		{
			std::cout << m_Para.m_ModC << std::endl;
			sprintf_s(tmpStr, "%sAdp%s%sC%.0fR", g_LidarFolder, m_Para.m_PointSelMethod.c_str(),
				m_Para.m_CorrepMethod, m_Para.m_ModC);
		}
		else
		{
			//std::cout << m_Para.m_ModC << std::endl;
			sprintf_s(tmpStr, "%sFix%s%sC%.0fR", g_LidarFolder, m_Para.m_PointSelMethod.c_str(),
				m_Para.m_CorrepMethod, m_Para.m_ModC);
		}
		std::cout << tmpStr << std::endl;
		if (_mkdir(tmpStr))
		{
			std::cout << "Error: Output Folder is not Created!\n";
			exit(-1);
		}
		m_LogDir = std::string(tmpStr);
	}


	~CAdpInEKF() {
		m_vImuPose.clear();
		m_vLocPose.clear();
		clear();
		m_MapPN_ptr->clear();
		m_MapP_ptr->clear();
		//CloseLogFile();
	}
	//	clear once loop
	void clear() {
		//SaveLocInfo();
		m_InaHdl_ptr->clear();
		m_EKFHdl_ptr->clear();
		m_RegHdl_ptr->clear();
		m_OutHdl_ptr->clear();
		m_OutTra_ptr->clear();
		m_FitHdl_ptr->clear();
	}
	//-------------------------------------------------------------------------
	pcl::PointCloud<pcl::PointXYZ>::Ptr GetOutHdlPtr() { return m_OutHdl_ptr; }
	pcl::PointCloud<pcl::PointXYZ>::Ptr GetGeneTraPtr() { return m_OutTra_ptr; }
	float GetFitScore() { return m_FitScore; }
	int GetHdlLen() { return m_OutHdl_ptr->size(); }
	int GetnFrm() { return m_nFrm; }

	void LoadFullMap() {
		//std::string FileName = m_MapRoot + "HDMap.pcd"; // or m_Para.m_MapFile
		std::string FileName = m_Para.m_MapFile;
		if (pcl::io::loadPCDFile<pcl::PointNormal>(FileName.c_str(), *m_MapPN_ptr) < 0) {
			std::cout << "Cannot get the HDMap.pcd file!" << std::endl;
			exit(-1);
		}
		m_MapPN_ptr->width = m_MapPN_ptr->size();
		m_MapPN_ptr->height = 1;
		m_MapPN_ptr->is_dense = false;
		std::cout << "Number of Raw Map points is: " << m_MapPN_ptr->size() << std::endl;
		m_MapPN_ptr = RemoveNaNFromPC(m_MapPN_ptr);
		//-----------  added in 2020-11-27 ---------------- 
		clock_t aaa, bbb;
		aaa = clock();
		m_MapPN_ptr = DownRandomPN(m_MapPN_ptr, m_Para.m_MapRandomDownRes); // about 2000
																			//m_MapPN_ptr = DownRandPermPN(m_MapPN_ptr, m_Para.m_MapRandomDownRes); // need more time about 6900
		bbb = clock();
		std::cout << "Map downsample need : " << bbb - aaa << std::endl;
		//-------------------------------------------------
		std::cout << "Number of New Map points is: " << m_MapPN_ptr->size() << std::endl;
		CNormalToXYZ(m_MapPN_ptr, m_MapP_ptr);
		std::cout << "m_MapXYZNor_ptr size is    : " << m_MapPN_ptr->size() << std::endl;
		pcl::search::KdTree<pcl::PointXYZ>::Ptr search_tmp1(new pcl::search::KdTree<pcl::PointXYZ>);
		search_tmp1->setInputCloud(m_MapP_ptr);
		m_KdMapP_ptr = search_tmp1;

		pcl::search::KdTree<pcl::PointNormal>::Ptr search_tmp2(new pcl::search::KdTree<pcl::PointNormal>);
		search_tmp2->setInputCloud(m_MapPN_ptr);
		m_KdMapPN_ptr = search_tmp2;
		std::cout << "Convert map data to PCL success!\t" << std::endl;
		SaveHdlPCD("MapDRP", "D:\\ProgramUsingCPP\\AomEKF\\AomEKF\\", m_MapP_ptr, 1);
	}
	//
	void load(const int nFrm) { // 
		clock_t a, b, c;
		a = clock();
		if (m_Para.m_isUseDataRoot == 1)
		{
			// HDL data read directly.
		}
		else
		{
			char HdlName[200] = "\0";
			sprintf_s(HdlName, "%sPcd%06d.pcd", m_HdlRoot.c_str(), nFrm);
			//std::cout << "HdlName : " << HdlName << std::endl;
			if (pcl::io::loadPCDFile(HdlName, *m_InaHdl_ptr) < 0) {//	support single type
				std::cout << "At the End of RandomHdl.txt! " << std::endl;
				exit(-1);
			}
			m_InaHdl_ptr->width = m_InaHdl_ptr->size();
			m_InaHdl_ptr->height = 1;
			m_InaHdl_ptr->is_dense = false;
		}
		b = clock();
		DownCutFun();	// generating m_RegHdl_ptr and m_EKFHdl_ptr
		c = clock();
	}
	//-------------------------------------------
	void DownCutFun()
	{
		clock_t a, b, c, d, e;
		a = clock();
		m_EKFHdl_ptr->clear();
		m_RegHdl_ptr->clear();
		pcl::PointCloud<pcl::PointXYZ>::Ptr CutRaw_Ptr(new pcl::PointCloud<pcl::PointXYZ>);
		CutRaw_Ptr = LimitRange(m_InaHdl_ptr, m_Para.m_MinR, m_Para.m_MaxR);
		//pcl::PointCloud<pcl::PointXYZ>::Ptr TraRaw_Ptr(new pcl::PointCloud<pcl::PointXYZ>);
		//pcl::transformPointCloud(*CutRaw_Ptr, *TraRaw_Ptr, m_Para.m_CalTF);

		//SaveHdlPCD("CurRaw", "D:\\ProgramUsingCPP\\AdpInEKF\\AdpInEKF\\", CutRaw_Ptr, 1);

		b = clock();
		if (0 == m_Para.m_PointSelMethod.compare("Random")) // Random Grid Loam
		{
			double Res = m_Para.m_PtNum / (double)CutRaw_Ptr->points.size();
			m_EKFHdl_ptr = DownRandom(CutRaw_Ptr, Res);
			//m_EKFHdl_ptr = DownRandPermP(CutRaw_Ptr, Res);//DownRandPermP
		}
		else if (0 == m_Para.m_PointSelMethod.compare("Grid"))
		{
			double GridSize = m_Para.m_GridRes;
			m_EKFHdl_ptr = DownGird(CutRaw_Ptr, GridSize);
		}
		else if (0 == m_Para.m_PointSelMethod.compare("Loam")) // From Loam SLAM
		{
			// NULL
		}
		c = clock();
		m_RegHdl_ptr = DownRandom(CutRaw_Ptr, 0.03); // 2020-12-04
		d = clock();
		m_FitHdl_ptr = DownGird(CutRaw_Ptr, 0.25);
		e = clock();
	}
	//----------------------------------------------------------------------
	//	
	//----------------------------------------------------------------------
	Mat3d GetQKCovQ4(const Vec3d& Zk) // 2020-11-27 new version
	{
		Mat3d tmpQk = Mat3d::Identity();
		if (m_Para.m_isAdp == 1)
		{
			pcl::PointXY tmpR;
			tmpR.x = Zk.norm();		tmpR.y = 0.0;
			std::vector<int> vIdx;
			std::vector<float> vDist;
			m_Para.m_KdvEstRads_ptr->nearestKSearch(tmpR, 1, vIdx, vDist);
			Vec4d tmpMCov = m_Para.m_vMeaCov[vIdx[0]];
			Vec4d tmpDCov = m_Para.m_vDq4Cov[vIdx[0]];
			pcl::PointXYZ Pt;
			Pt.x = Zk(0); Pt.y = Zk(1); Pt.z = Zk(2);
			int UniQ = Quadrant(Pt);
			double Dvar = tmpDCov(UniQ - 1); // attention!!!  2020-11-30
			Vec3d tmpCov;
			tmpCov(0) = tmpMCov(1) + Dvar;
			tmpCov(1) = tmpMCov(2) + Dvar;
			tmpCov(2) = tmpMCov(3) + Dvar;
			tmpQk = tmpCov.asDiagonal();
		}
		else
		{
			Vec4d tmpCov = m_Para.m_vStdCov[0];
			tmpQk = tmpCov.block<3, 1>(1, 0).asDiagonal();
		}
		tmpQk = tmpQk * m_Para.m_ModC;	//	very important!
										//std::cout << m_Para.m_ModC << std::endl;
										//std::cout << tmpQk << std::endl;
		return tmpQk;
	}
	//----------------------------------------------------------------------
	//
	//----------------------------------------------------------------------
	Mat4d TransformationFEstmation(const Mat4d & InitT)
	{
		Mat4d GeneT = Mat4d::Identity();
		if (0 == m_Para.m_CorrepMethod.compare("Knn"))
		{
			GeneT = InitT;
		}
		else if (0 == m_Para.m_CorrepMethod.compare("IcpSVD"))
		{
			GeneT = ScanMatchP2PuSVD(InitT, m_RegHdl_ptr);
		}
		else if (0 == m_Para.m_CorrepMethod.compare("Icp"))
		{
			GeneT = ScanMatchP2PL(InitT, m_RegHdl_ptr);
		}
		else if (0 == m_Para.m_CorrepMethod.compare("IcpLM"))
		{
			GeneT = ScanMatchP2PLuLM(InitT, m_RegHdl_ptr);
		}
		else if (0 == m_Para.m_CorrepMethod.compare("Ndt"))
		{
			GeneT = ScanMatchNdt(InitT, m_RegHdl_ptr);
		}
		else
		{
			std::cout << "The correspondences step is error. [Data Association]" << std::endl;
			exit(-1);
		}
		return GeneT;
	}
	//----------------------------------------------------------------------
	//
	//----------------------------------------------------------------------
	int FindCorrespondencesM(const Mat4d & GeneT, std::vector<Vec3d>& vHdlPts, std::vector<Vec3d>& vMapPts)
	{
		pcl::PointCloud<pcl::PointXYZ> vTranPts;
		pcl::transformPointCloud(*m_EKFHdl_ptr, vTranPts, GeneT.cast<float>());
		vHdlPts.clear();
		vMapPts.clear();
		int nCnt = 0;
		float maxCorrectDist = std::pow(m_Para.m_CorrectThr, 2);
		for (int i = 0; i < vTranPts.points.size(); i++)
		{
			std::vector<int> vIdx;
			std::vector<float> vDist;
			m_KdMapP_ptr->nearestKSearch(vTranPts.points[i], 1, vIdx, vDist);
			if (vDist[0] <= maxCorrectDist)
			{
				//vHdlPts->points.push_back(m_EKFHdl_ptr->points[i]); // very important!
				//vMapPts->points.push_back(m_MapP_ptr->points[vIdx[0]]);
				Vec3d tmpPt;
				tmpPt(0) = (double)m_EKFHdl_ptr->points[i].x;
				tmpPt(1) = (double)m_EKFHdl_ptr->points[i].y;
				tmpPt(2) = (double)m_EKFHdl_ptr->points[i].z;
				vHdlPts.emplace_back(tmpPt);	// original point
				tmpPt(0) = (double)m_MapP_ptr->points[vIdx[0]].x;
				tmpPt(1) = (double)m_MapP_ptr->points[vIdx[0]].y;
				tmpPt(2) = (double)m_MapP_ptr->points[vIdx[0]].z;
				vMapPts.emplace_back(tmpPt);	// map point
				nCnt++;
			}
		}
		return (nCnt > 20) ? 1 : 0;
	}
	//
	int Quadrant(const pcl::PointXYZ& Pt)
	{
		if ((Pt.x >= 1e-6) && (Pt.y >= 1e-6)) { return 1; }
		else if ((Pt.x <= 1e-6) && (Pt.y >= 1e-6)) { return 2; }
		else if ((Pt.x <= 1e-6) && (Pt.y <= 1e-6)) { return 3; }
		else { return 4; }
	}
	//
	void FindvDistErrorP2PL(const double MaxThr, const Mat4d& GeneTF, pcl::PointCloud<pcl::PointXY>::Ptr& vHdlRads, std::vector<double>& vRadErrs)
	{
		pcl::PointCloud<pcl::PointXYZ>::Ptr Hdl_ptr(new pcl::PointCloud<pcl::PointXYZ>);
		pcl::transformPointCloud(*m_FitHdl_ptr, *Hdl_ptr, GeneTF.cast<float>());
		float maxCorrectDist = std::pow(MaxThr, 2);
		size_t Len = Hdl_ptr->size();
		for (int i = 0; i < Len; i++) {
			std::vector<int> vIdx;
			std::vector<float> vDist;
			pcl::PointXYZ pt_src = Hdl_ptr->points[i];
			pcl::PointXYZ pt_raw = m_FitHdl_ptr->points[i];
			m_KdMapP_ptr->nearestKSearch(pt_src, 1, vIdx, vDist);
			if (vDist[0] <= maxCorrectDist) {
				pcl::PointNormal refPt = m_MapPN_ptr->points[vIdx[0]];
				float dx = pt_src.x - refPt.x;
				float dy = pt_src.y - refPt.y;
				float dz = pt_src.z - refPt.z;
				float nx = refPt.normal_x;
				float ny = refPt.normal_y;
				float nz = refPt.normal_z;
				float fDist_pl = abs(nx*dx + ny*dy + nz*dz);
				pcl::PointXY tmpPt;
				tmpPt.x = Norm(pt_raw);
				tmpPt.y = 0.0;
				vHdlRads->points.emplace_back(tmpPt);
				vRadErrs.emplace_back(fDist_pl);
			}
		}
	}
	//
	void FindvDistErrorP2PLQ4(const double MaxThr, const Mat4d& GeneTF,
		pcl::PointCloud<pcl::PointXY>::Ptr& vHdlRadsQ1, std::vector<double>& vRadErrsQ1,
		pcl::PointCloud<pcl::PointXY>::Ptr& vHdlRadsQ2, std::vector<double>& vRadErrsQ2,
		pcl::PointCloud<pcl::PointXY>::Ptr& vHdlRadsQ3, std::vector<double>& vRadErrsQ3,
		pcl::PointCloud<pcl::PointXY>::Ptr& vHdlRadsQ4, std::vector<double>& vRadErrsQ4)
	{
		pcl::PointCloud<pcl::PointXYZ>::Ptr Hdl_ptr(new pcl::PointCloud<pcl::PointXYZ>);
		pcl::transformPointCloud(*m_FitHdl_ptr, *Hdl_ptr, GeneTF.cast<float>());

		float maxCorrectDist = std::pow(MaxThr, 2);
		size_t Len = Hdl_ptr->size();
		for (int i = 0; i < Len; i++) {
			std::vector<int> vIdx;
			std::vector<float> vDist;
			pcl::PointXYZ pt_src = Hdl_ptr->points[i];
			pcl::PointXYZ pt_raw = m_FitHdl_ptr->points[i];
			m_KdMapP_ptr->nearestKSearch(pt_src, 1, vIdx, vDist);
			if (vDist[0] <= maxCorrectDist) {
				pcl::PointNormal refPt = m_MapPN_ptr->points[vIdx[0]];
				float dx = pt_src.x - refPt.x;
				float dy = pt_src.y - refPt.y;
				float dz = pt_src.z - refPt.z;
				float nx = refPt.normal_x;
				float ny = refPt.normal_y;
				float nz = refPt.normal_z;
				float fDist_pl = std::abs(nx*dx + ny*dy + nz*dz);

				pcl::PointXY tmpPt;
				tmpPt.x = Norm(pt_raw); // very important! 20201127
				tmpPt.y = 0.0;
				if ((pt_raw.x >= 1e-6) && (pt_raw.y >= 1e-6))
				{
					vHdlRadsQ1->points.emplace_back(tmpPt);
					vRadErrsQ1.emplace_back(fDist_pl);
				}
				else if ((pt_raw.x <= 1e-6) && (pt_raw.y >= 1e-6))
				{
					vHdlRadsQ2->points.emplace_back(tmpPt);
					vRadErrsQ2.emplace_back(fDist_pl);
				}
				else if ((pt_raw.x <= 1e-6) && (pt_raw.y <= 1e-6))
				{
					vHdlRadsQ3->points.emplace_back(tmpPt);
					vRadErrsQ3.emplace_back(fDist_pl);
				}
				else
				{
					vHdlRadsQ4->points.emplace_back(tmpPt);
					vRadErrsQ4.emplace_back(fDist_pl);
				}
			}
		}
	}
	//
	std::vector<double> ExtractPts(const std::vector<double>& vRadErrs, const std::vector<int>& vIdx)
	{
		if (vRadErrs.size() < vIdx.size())
		{
			std::cout << "The size of errors is less than the size of vidx![ExtractPts()]" << std::endl;
			exit(-1);
		}
		std::vector<double> vSubErrs;
		for (size_t i = 0; i < vIdx.size(); i++)
		{
			vSubErrs.push_back(vRadErrs[vIdx[i]]);
		}
		return vSubErrs;
	}
	//
	std::vector<double> StatisFun(const pcl::PointCloud<pcl::PointXY>::Ptr& vHdlRads, const std::vector<double>& vRadErrs)
	{
		pcl::search::KdTree<pcl::PointXY>::Ptr KdTree(new pcl::search::KdTree<pcl::PointXY>);
		KdTree->setInputCloud(vHdlRads);
		std::vector<double> vVariance;
		for (float R = m_Para.m_MinR; R < m_Para.m_MaxR; R = R + m_Para.m_dR)
		{
			pcl::PointXY qPt;
			qPt.x = R;
			qPt.y = 0.0;
			double queR = m_Para.m_dR / 2;
			std::vector<int>  vIdx;
			std::vector<float> k_Dist;
			KdTree->radiusSearch(qPt, queR, vIdx, k_Dist);
			if (vIdx.size() < 5) {
				if (R == m_Para.m_MinR) {
					vVariance.push_back(0.01); // 1e-2
				}
				else {
					vVariance.push_back(vVariance.back());
				}
			}
			else {
				std::vector<double> vRads = ExtractPts(vRadErrs, vIdx);
				//SaveVecData("vRads.txt", vRads);
				vVariance.push_back(CalVar(vRads));
			}
		}
		return vVariance;
	}
	//---------------------------------------------------
	std::vector<Vec4d> GeneTrainDataViaQ4(const Mat4d& GeneTF)
	{	// quat-1 quat-2 quat-3 quat-4
		const double MaxThr = m_Para.m_TrainThr;
		pcl::PointCloud<pcl::PointXY>::Ptr vHdlRadsQ1(new pcl::PointCloud<pcl::PointXY>);
		pcl::PointCloud<pcl::PointXY>::Ptr vHdlRadsQ2(new pcl::PointCloud<pcl::PointXY>);
		pcl::PointCloud<pcl::PointXY>::Ptr vHdlRadsQ3(new pcl::PointCloud<pcl::PointXY>);
		pcl::PointCloud<pcl::PointXY>::Ptr vHdlRadsQ4(new pcl::PointCloud<pcl::PointXY>);
		std::vector<double> vRadErrsQ1;
		std::vector<double> vRadErrsQ2;
		std::vector<double> vRadErrsQ3;
		std::vector<double> vRadErrsQ4;
		FindvDistErrorP2PLQ4(MaxThr, GeneTF, vHdlRadsQ1, vRadErrsQ1,
			vHdlRadsQ2, vRadErrsQ2, vHdlRadsQ3, vRadErrsQ3, vHdlRadsQ4, vRadErrsQ4);
		std::vector<std::vector<double>> vCoarseVar;
		vCoarseVar.push_back(StatisFun(vHdlRadsQ1, vRadErrsQ1));
		vCoarseVar.push_back(StatisFun(vHdlRadsQ2, vRadErrsQ2));
		vCoarseVar.push_back(StatisFun(vHdlRadsQ3, vRadErrsQ3));
		vCoarseVar.push_back(StatisFun(vHdlRadsQ4, vRadErrsQ4));
		std::vector<Vec4d> nCov = CvvDD2vVec4d(vCoarseVar);
		//VecVec4dShow(nCov);
		//std::cout << "nCov size : " << nCov.size() << std::endl;
		return nCov;
	}
	//---------------------------------------------------
	std::vector<Vec4d> GeneTrainDataWithP2PL(const Mat4d& GeneTF)
	{	// rads var-x var-y var-z
		const double MaxThr = m_Para.m_TrainThr;
		pcl::PointCloud<pcl::PointXY>::Ptr vHdlRads(new pcl::PointCloud<pcl::PointXY>);
		std::vector<double> vRadErrs;
		FindvDistErrorP2PL(MaxThr, GeneTF, vHdlRads, vRadErrs);

		std::vector<double> coarseVar = StatisFun(vHdlRads, vRadErrs);
		//std::vector<double> refineVar = m_Para.TestGPDouble(coarseVar);
		std::vector<Vec4d> nCov = CvDouble2vVec4d(coarseVar);
		return nCov;
	}
	//----------------------------------------------------------------------
	//	Invariant EKF propagation step
	//----------------------------------------------------------------------
	void MotionM(const Mat4d& CurImuT, const Mat4d& PreImuT,
		Mat6d & Fx, Mat6d & Gu, Mat4d & Xbar)
	{
		Mat4d DifTF = PreImuT.inverse() * CurImuT;
		Xbar = m_TFK_1 * DifTF;

		// Invariant EKF 
		Fx = Mat6d::Identity();
		Gu = AdjTF(Xbar);
		//std::cout << Gu << std::endl;
	}
	//----------------------------------------------------------------------
	//	Invariant EKF update step
	//----------------------------------------------------------------------
	void Update4Q(const Mat4d& XbarK, const Mat6d& CbarK)
	{
		std::vector<Vec3d> vHdlPts;
		std::vector<Vec3d> vMapPts;
		m_CovK = CbarK;
		m_TFK = XbarK;
		Mat4d EstTF = TransformationFEstmation(XbarK);

		Vec6d ImuPre = CTF2Pose(XbarK);
		Vec6d RegCal = CTF2Pose(EstTF);
		double distT = SEdistT(ImuPre, RegCal);
		double distR = SEdistR(ImuPre, RegCal);
		Vec4d tmpLogInfo;
		tmpLogInfo(0) = m_nFrm;
		tmpLogInfo(2) = distT;
		tmpLogInfo(3) = distR;
		m_vLogInfo.push_back(tmpLogInfo);

		int isNumPts = FindCorrespondencesM(EstTF, vHdlPts, vMapPts);
		if (isNumPts == 1)
		{
			if (m_Para.m_isAdp == 1)
			{
				std::vector<Vec4d> vNewV = GeneTrainDataViaQ4(EstTF);// version 3
				m_Para.TestGP4Q(vNewV);	// m_vDq4Cov
			}
			size_t Len = vHdlPts.size();
			m_ErrorTF = Mat4d::Identity();
			for (int i = 0; i < Len; i++) {
				Vec3d Zkv = vHdlPts[i];
				Mat3d Qk = GetQKCovQ4(Zkv);	//    What a painful understanding!!				

				Mat3d Rk = XbarK.block<3, 3>(0, 0);
				Vec3d Tk = XbarK.block<3, 1>(0, 3);
				Vec3d Zkw = Rk * Zkv + Tk;	// to map coordinate

				// Hx = [skew(vMapPts(i,:)), -eye(3)];
				Mat36 Hx;
				Hx.block<3, 3>(0, 0) = SkewD(vMapPts[i]);
				Hx.block<3, 3>(0, 3) = -Mat3d::Identity();

				//	InEKF update step
				Mat3d Sk = Hx * CbarK * Hx.transpose() + Qk;
				Mat63 Kk = CbarK * Hx.transpose() * Sk.inverse();
				//-------------------------------------------------
				m_ErrorTF = ExpFun(Kk * (Zkw - vMapPts[i])) * m_ErrorTF;
				//std::cout << "Zkw: " << Zkw << std::endl;
				//std::cout << "vMapPts[i]: " << vMapPts[i] << std::endl;
				//std::cout << "ExpFun: " << ExpFun(Kk * (Zkw - vMapPts[i])) << std::endl;
				//-------------------------------------------------
				m_CovK = (Mat6d::Identity() - Kk * Hx) * m_CovK;
			}
			m_TFK = m_ErrorTF * XbarK;
			m_StateK = CTF2State(m_TFK);	// ax, ay, az, x, y, z
			m_StateK(0) = warpToPi(m_StateK(0));
			m_StateK(1) = warpToPi(m_StateK(1));
			m_StateK(2) = warpToPi(m_StateK(2));
		}
	}
	//----------------------------------------------------------------------
	//	
	//----------------------------------------------------------------------
	double CalFitScoreCors(double maxDist)
	{
		pcl::Correspondences tmpCors;
		m_Correspond.setInputSource(m_OutHdl_ptr);
		m_Correspond.determineCorrespondences(tmpCors, maxDist);
		return tmpCors.size() / (double)m_OutHdl_ptr->points.size();
	}
	//
	float CalFitScorePP(float maxDist) {
		int nCnt = 0;
		for (int i = 0; i < m_OutHdl_ptr->points.size(); i++)
		{
			std::vector<int> vIdx;
			std::vector<float> vDist;
			pcl::PointXYZ pt_src = m_OutHdl_ptr->points[i];
			m_KdMapP_ptr->nearestKSearch(pt_src, 1, vIdx, vDist);
			int nIdx = vIdx[0];
			pcl::PointNormal refPt = m_MapPN_ptr->points[nIdx];
			float dx = pt_src.x - refPt.x;
			float dy = pt_src.y - refPt.y;
			float dz = pt_src.z - refPt.z;
			float nx = refPt.normal_x, ny = refPt.normal_y, nz = refPt.normal_z;
			float fDist_pl = abs(nx*dx + ny*dy + nz*dz);
			if (fDist_pl <= maxDist)
			{
				nCnt++;
			}
		}
		float ratio = float(nCnt) / m_OutHdl_ptr->points.size();
		return ratio;
	}
	//----------------------------------------------------------------------
	//	PCL display
	//----------------------------------------------------------------------
	void ConfigMatcher() {
		if (0 == m_Para.m_CorrepMethod.compare("Icp"))
		{
			pcl::registration::TransformationEstimationPointToPlaneLLS<pcl::PointNormal, pcl::PointNormal>::Ptr trans_lls(new pcl::registration::TransformationEstimationPointToPlaneLLS<pcl::PointNormal, pcl::PointNormal>);
			m_P2PlMatcher.setTransformationEstimation(trans_lls);
			m_P2PlMatcher.setMaxCorrespondenceDistance(2);
			m_P2PlMatcher.setMaximumIterations(m_Para.m_RegMaxIterNum);
			m_P2PlMatcher.setTransformationEpsilon(0.0001);
			m_P2PlMatcher.setEuclideanFitnessEpsilon(0.00009);
			m_P2PlMatcher.setSearchMethodTarget(m_KdMapPN_ptr, true);
			m_P2PlMatcher.setInputTarget(m_MapPN_ptr);
		}
		if (0 == m_Para.m_CorrepMethod.compare("IcpLM"))
		{
			m_P2PluLM.setMaxCorrespondenceDistance(2);
			m_P2PluLM.setMaximumIterations(m_Para.m_RegMaxIterNum);
			m_P2PluLM.setTransformationEpsilon(0.0001);
			m_P2PluLM.setEuclideanFitnessEpsilon(0.00009);
			m_P2PluLM.setSearchMethodTarget(m_KdMapPN_ptr, true);
			m_P2PluLM.setInputTarget(m_MapPN_ptr);
		}
		if (0 == m_Para.m_CorrepMethod.compare("IcpSVD"))
		{
			pcl::registration::TransformationEstimationSVD<pcl::PointXYZ, pcl::PointXYZ>::Ptr trans_svd(new pcl::registration::TransformationEstimationSVD<pcl::PointXYZ, pcl::PointXYZ>);
			m_P2PICP.setTransformationEstimation(trans_svd);
			m_P2PICP.setMaximumIterations(m_Para.m_RegMaxIterNum);
			m_P2PICP.setMaxCorrespondenceDistance(2.0);
			m_P2PICP.setEuclideanFitnessEpsilon(0.00009);
			m_P2PICP.setTransformationEpsilon(0.0001);
			m_P2PICP.setSearchMethodTarget(m_KdMapP_ptr, true);
			m_P2PICP.setInputTarget(m_MapP_ptr);
		}
		if (0 == m_Para.m_CorrepMethod.compare("Ndt"))
		{
			m_Ndt.setTransformationEpsilon(0.0001);
			m_Ndt.setStepSize(0.2);
			m_Ndt.setResolution(3.0);
			m_Ndt.setMaximumIterations(m_Para.m_RegMaxIterNum);
			m_Ndt.setMaxCorrespondenceDistance(2);
			m_Ndt.setOulierRatio(0.8);	// same to matlab
			m_Ndt.setEuclideanFitnessEpsilon(0.00009);
			//m_Ndt.setInputTarget(m_MapP_ptr); // 2021-03-13
		}
	}
	Mat4d ScanMatchP2PL(const Mat4d& InitTF, const pcl::PointCloud<pcl::PointXYZ>::Ptr & IcpPts_ptr)
	{
		pcl::PointCloud<pcl::PointNormal>::Ptr Source_ptr(new pcl::PointCloud<pcl::PointNormal>);
		EstHdlNormalFalse(IcpPts_ptr, Source_ptr);
		pcl::PointCloud<pcl::PointNormal>::Ptr Output_ptr(new pcl::PointCloud<pcl::PointNormal>);
		m_P2PlMatcher.setInputSource(Source_ptr);
		m_P2PlMatcher.align(*Output_ptr, InitTF.cast<float>());
		return m_P2PlMatcher.getFinalTransformation().cast<double>();
	}
	Mat4d ScanMatchP2PLuLM(const Mat4d& InitTF, const pcl::PointCloud<pcl::PointXYZ>::Ptr & IcpPts_ptr)
	{
		pcl::PointCloud<pcl::PointNormal>::Ptr Source_ptr(new pcl::PointCloud<pcl::PointNormal>);
		EstHdlNormalFalse(IcpPts_ptr, Source_ptr);
		pcl::PointCloud<pcl::PointNormal>::Ptr Output_ptr(new pcl::PointCloud<pcl::PointNormal>);
		m_P2PluLM.setInputSource(Source_ptr);
		m_P2PluLM.align(*Output_ptr, InitTF.cast<float>());
		return m_P2PluLM.getFinalTransformation().cast<double>();
	}
	Mat4d ScanMatchP2PuSVD(const Mat4d& InitTF, const pcl::PointCloud<pcl::PointXYZ>::Ptr & IcpPts_ptr)
	{
		pcl::PointCloud<pcl::PointXYZ>::Ptr Output_ptr(new pcl::PointCloud<pcl::PointXYZ>);
		m_P2PICP.setInputSource(IcpPts_ptr);
		m_P2PICP.align(*Output_ptr, InitTF.cast<float>());		// pCloud_aligned
		return m_P2PICP.getFinalTransformation().cast<double>();
	}
	Mat4d ScanMatchNdt(const Mat4d& InitTF, const pcl::PointCloud<pcl::PointXYZ>::Ptr & NdtPts_ptr)
	{
		pcl::PointCloud<pcl::PointXYZ>::Ptr Output_ptr(new pcl::PointCloud<pcl::PointXYZ>);
		//m_Ndt.setInputTarget(m_MapP_ptr);

		pcl::PointCloud<pcl::PointXYZ>::Ptr SubMap_ptr(new pcl::PointCloud<pcl::PointXYZ>);
		SubMap_ptr = SubMapP2P(m_KdMapP_ptr, m_MapP_ptr, InitTF);
		pcl::search::KdTree<pcl::PointXYZ>::Ptr SubMapKd(new pcl::search::KdTree<pcl::PointXYZ>);
		SubMapKd->setInputCloud(SubMap_ptr);
		m_Ndt.setSearchMethodTarget(SubMapKd, true);
		m_Ndt.setInputTarget(SubMap_ptr);

		m_Ndt.setInputSource(NdtPts_ptr);
		m_Ndt.align(*Output_ptr, InitTF.cast<float>());
		return m_Ndt.getFinalTransformation().cast<double>();
	}

	//------------------------------------------------------------------------------------------------
	//
	//------------------------------------------------------------------------------------------------

	void InitViewer() {
		m_Viewer.setWindowName("3D Map Localization");
		m_Viewer.addCoordinateSystem(1);
		m_Viewer.setWindowBorders(true);
		m_Viewer.setSize(1000, 600);
		m_Viewer.setBackgroundColor(0.0, 0.0, 0.0);
		m_Viewer.setCameraPosition(0, 0, 100, 0, 0, 0);	//

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> InaColor(m_InaShow_ptr, 255, 0, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_InaShow_ptr, InaColor, "Raw data");    //��ʾ���ƣ�����fildColorΪ��ɫ��ʾ
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Raw data");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointNormal> MapColor(m_MapShow_ptr, 190, 190, 190);
		m_Viewer.addPointCloud<pcl::PointNormal>(m_MapShow_ptr, MapColor, "Map data");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Map data");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Gene_Tra(m_TraShow_ptr, 255, 255, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_TraShow_ptr, Gene_Tra, "EKF-Gene-Tra");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "EKF-Gene-Tra");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Gps_Tra(m_GpsShow_ptr, 255, 0, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_GpsShow_ptr, Gps_Tra, "Gps-Tra");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Gps-Tra");

		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Imu_Tra(m_ImuShow_ptr, 128, 128, 0);
		m_Viewer.addPointCloud<pcl::PointXYZ>(m_ImuShow_ptr, Imu_Tra, "Imu-Tra");
		m_Viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, "Imu-Tra");

		m_Viewer.addText(m_DisInfo, 20, 20, 18, 1.0, 1.0, 0.0, "Process information");
	}

	bool isViewStop() { return m_Viewer.wasStopped(); }

	void show() {

		Eigen::Matrix4f tmpTF = m_TFK.inverse().cast<float>();
		pcl::transformPointCloud(*m_MapPN_ptr, *m_MapShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointNormal> MapColor(m_MapShow_ptr, 190, 190, 190);
		m_Viewer.updatePointCloud<pcl::PointNormal>(m_MapShow_ptr, MapColor, "Map data");

		RandomDownSample(m_InaHdl_ptr, m_InaShow_ptr, 0.9);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> InaColor(m_InaShow_ptr, 255, 0, 0);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_InaShow_ptr, InaColor, "Raw data");    //��ʾ���ƣ�����fildColorΪ��ɫ��ʾ

		pcl::transformPointCloud(*m_OutTra_ptr, *m_TraShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Gene_Tra(m_TraShow_ptr, 255, 255, 0);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_TraShow_ptr, Gene_Tra, "EKF-Gene-Tra");

		pcl::transformPointCloud(*m_pGpsPose, *m_GpsShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Grd_Tra(m_GpsShow_ptr, 255, 0, 0);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_GpsShow_ptr, Grd_Tra, "Gps-Tra");

		//Eigen::Matrix4f OrgTF = CPose2TF(m_vImuPose[0]).inverse().cast<float>() * tmpTF;
		pcl::transformPointCloud(*m_pLocPose, *m_ImuShow_ptr, tmpTF);
		pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> Imu_Tra(m_ImuShow_ptr, 128, 128, 128);
		m_Viewer.updatePointCloud<pcl::PointXYZ>(m_ImuShow_ptr, Imu_Tra, "Imu-Tra");

		m_Viewer.updateText(m_DisInfo, 20, 20, 18, 1.0, 1.0, 0.0, "Process information");
		m_Viewer.spinOnce(10);
	}

	void SetDisInfo(const std::string & DispInfo) { m_DisInfo = DispInfo; }

	void SaveViewer(const int& nFrm, const std::string & ImgFolder) {
		char FileName[100] = " ";
		sprintf_s(FileName, "%sLocImage%06d.png", ImgFolder.c_str(), nFrm);
		m_Viewer.saveScreenshot(std::string(FileName));
	}
	//
	void saveGpsImuPose(const Vec6d& CurImu, const Vec6d& CurGps)
	{
		pcl::PointXYZ tmpPt;
		tmpPt.x = CurGps(0);
		tmpPt.y = CurGps(1);
		tmpPt.z = CurGps(2);
		m_pGpsPose->points.push_back(tmpPt);
		tmpPt.x = CurImu(0);
		tmpPt.y = CurImu(1);
		tmpPt.z = CurImu(2);
		m_pLocPose->points.push_back(tmpPt);
	}
	//----------------------------------------------------------------------
	//	process and show
	//----------------------------------------------------------------------
	void ProcessShow()		//const Vec6d& CurImu
	{
		clock_t sss, aaa, bbb, ccc;
		size_t FrmLen = m_Para.m_vImuPose.size();
		m_nFrm = m_Para.m_StartID;

		while (true) {
			if (m_nFrm == FrmLen) { break; }
			int SelIdx = m_Para.m_vSelIdx[m_nFrm];
			sss = clock();
			load(SelIdx);
			aaa = clock();
			Vec6d CurImu = m_Para.m_vImuPose[m_nFrm];
			Vec6d CurGps = m_Para.m_vGrdPose[m_nFrm];
			saveGpsImuPose(CurImu, CurGps);

			Mat6d Fx = Mat6d::Identity();
			Mat6d Gu = Mat6d::Zero();
			Mat4d XbarK = Mat4d::Identity();
			Mat6d CbarK = Mat6d::Identity();
			if (m_Para.m_StartID == m_nFrm)	// the first step
			{
				XbarK = m_TFK_1;
			}
			else
			{
				Vec6d PreImu = m_vImuPose.back();
				Mat4d CurImuTF = CPose2TF(CurImu);
				Mat4d PreImuTF = CPose2TF(PreImu);
				MotionM(CurImuTF, PreImuTF, Fx, Gu, XbarK);
			}
			CbarK = Fx * m_CovK_1 * Fx.transpose() + Gu * m_Mk * Gu.transpose();

			Update4Q(XbarK, CbarK);
			m_TFK = CState2TF(m_StateK);
			m_TFK_1 = m_TFK;
			m_CovK_1 = m_CovK;
			m_PoseK = CState2Pose(m_StateK);

			m_vLocPose.push_back(m_PoseK);
			m_vImuPose.push_back(CurImu);

			bbb = clock();
			//pcl::transformPointCloud(*m_FitHdl_ptr, *m_OutHdl_ptr, m_TFK.cast<float>());
			//double tmpScore = CalFitScorePP(0.5);
			//m_FitScore = tmpScore;
			double distT = SEdistT(CurGps, m_PoseK);
			double distR = SEdistR(CurGps, m_PoseK);
			ccc = clock();

			char DisplayInfo[200] = " ";
			sprintf_s(DisplayInfo, "Frame: %05d, Read:%3dms, InEKFT:%3dms, Total:%4dms, ErrorDist: [%.04f,%.04f]", m_nFrm, aaa - sss, bbb - aaa, ccc - sss, distT, distR);
			printf("%s\n", DisplayInfo);

			SetDisInfo(DisplayInfo);
			show();

			//std::string ImgFolder = "D:\\ProgramUsingCPP\\LocMoreObsImage\\";
			//SaveViewer(m_nFrm, ImgFolder);

			clear();
			++m_nFrm;
		}
		std::cout << "The length of m_vLocPose is :  " << m_vLocPose.size() << std::endl;
		char LocFile[200] = "\0";
		sprintf_s(LocFile, "%s\\LocLog.txt", m_LogDir.c_str());
		SaveVec6dPose(LocFile, m_vLocPose);
	}
};

#endif
