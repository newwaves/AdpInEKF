#pragma once
#ifndef H_ADP_PARAMS_H
#define H_ADP_PARAMS_H


#include "stdafx.h"
#include "LocComFun.h"

#include <iostream>
#include <istream>
#include <vector>
#include <iosfwd>
#include <string>

//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
void ReadNoise(const std::string & TxtName, std::vector<Vec4d> & vCov)
{
	std::ifstream ifData;
	ifData.open(TxtName);
	if (!ifData)
	{
		std::cout << "Cannot get the parameter file!" << std::endl;
		exit(-1);
	}
	std::stringstream ss;
	std::string tmpStr;
	Vec4d TmpCov;
	vCov.clear();
	while (!ifData.eof())
	{
		getline(ifData, tmpStr);
		if (tmpStr.empty()) { continue; }
		ss.clear();
		ss.str(tmpStr);
		ss >> TmpCov(0) >> TmpCov(1) >> TmpCov(2) >> TmpCov(3);
		vCov.push_back(TmpCov);
	}
	ifData.close();
}

//************************************************************************
//
//************************************************************************
class CLocPara
{
private:

public:
	int		m_isAdp;			//	Adp : 1,  Other : 0
	int		m_isRTM;			//	1 - X = [R,t]-SO(3), 0 - X = T(SE(3))

	double	m_CorrectThr;
	double	m_TrainThr;
	double	m_ModC;
	std::string m_CorrepMethod;		// KNN ICP NDT
	int		m_RegMaxIterNum;		// Max iter num

	std::string m_PointSelMethod;	// Random Grid Loam
	double	m_GridRes;				// GridRes
	int		m_PtNum;				// PointNum
	double  m_MapRandomDownRes;		// Map random down resolution
	Mat4d   m_CalTF;				// Calibration TF (LiDAR and IMU)

	double	m_MinR;
	double	m_MaxR;
	double	m_dR;			//	delta radius for learning the Gp model
	size_t  m_GpRadRes;		//  Real_res = 0.1 * m_GpRadRes  for testing
	MatXX	m_K;
	MatXX	m_invK;
	std::vector<double>	m_vRads;	//	refine dRadius for more precise radius
	std::vector<double>	m_vNewR;	//	coarse radius for learning the GP model
	Vec6d	m_MotionCov;	//	[ax,ay,az, x, y, z] defined as [R,t]
	Vec6d   m_InitCov;
	//	[radius, cov1, cov2, cov3]
	std::vector<Vec4d>	m_vMeaCov;		//	measurement noise
	std::vector<Vec4d>	m_vDynCov;		//	dynamic noise
	std::vector<Vec4d>	m_vEstCov;		//	m_vEstCov = m_vMeaCov + m_vDynCov
	std::vector<Vec4d>	m_vStdCov;
	std::vector<Vec4d>	m_vDq4Cov;		//	dynamic noise version 3
										//	the data type is perfer to knnsearch method
	pcl::PointCloud<pcl::PointXY>::Ptr	m_vEstRads_Ptr;	// corresponding to m_vEstCov
	pcl::search::KdTree<pcl::PointXY>::Ptr m_KdvEstRads_ptr;

	std::vector<Vec6d>	m_vGrdPose;	//	x y z az ay ax
	std::vector<Vec6d>	m_vImuPose;	//
	std::vector<int>	m_vIdx;
	std::vector<int>	m_vSelIdx;
	int   m_StartID;	// From 1->end
	Mat4d m_StartTF;

	int m_isUseDataRoot;	//	1 DataRoot, 0 PcdRoot
	std::string m_MapRoot;
	std::string m_DataRoot;
	std::string m_PcdRoot;
	std::string m_MapFile;

	void clear()
	{
		m_vRads.clear();
		m_vNewR.clear();
		m_vMeaCov.clear();
		m_vDynCov.clear();
		m_vEstCov.clear();
		m_vStdCov.clear();
		m_vGrdPose.clear();
		m_vImuPose.clear();
		m_vIdx.clear();
		m_vSelIdx.clear();
	}
	void init()
	{
		for (float i = m_MinR; i <= m_MaxR; i = i + m_dR)
		{
			m_vNewR.push_back(i);
		}
		for (float i = m_MinR; i <= m_MaxR + 0.1; i = i + 0.1) // more precise raidus
		{
			m_vRads.push_back(i);
		}
		m_StartTF = CPose2TF(m_vGrdPose[m_StartID]); // m_StartID
		TrainGP();
		m_GpRadRes = 2;
		pcl::PointCloud<pcl::PointXY>::Ptr tmpPtr1(new pcl::PointCloud<pcl::PointXY>);
		m_vEstRads_Ptr = tmpPtr1;
		pcl::search::KdTree<pcl::PointXY>::Ptr KdvRads_ptr(new pcl::search::KdTree<pcl::PointXY>);
		m_KdvEstRads_ptr = KdvRads_ptr;
		//------------------------------------------------------------
		m_vEstRads_Ptr->clear();
		for (size_t i = 0; i < m_vRads.size(); i = i + m_GpRadRes)
		{
			pcl::PointXY tmpR;
			tmpR.x = m_vRads[i];
			tmpR.y = 0.0;
			m_vEstRads_Ptr->points.push_back(tmpR);
		}
		m_KdvEstRads_ptr->setInputCloud(m_vEstRads_Ptr);
		//------------------------------------------------------------
		TestGPInit();
	}

	//---------------------------------------------
	CLocPara()
	{
		read();
		init();
		show();
	}
	~CLocPara()
	{}

	//---------------------------------------------------------------------
	//
	//---------------------------------------------------------------------
	double KxxFun(const double&x1, const double&x2, const double& DeltaF)
	{
		double sigmaN = 0.0003 * 0.0003;
		double sigmaF = 0.01 * 0.01;
		double L = 2;
		double tmp = ((x1 - x2) * (x1 - x2)) / (2 * L * L);
		double Kxx = sigmaF * std::exp(-tmp) + sigmaN * DeltaF;
		//std::cout << "Kxx is : "<<Kxx << std::endl;
		//std::cout << "Exp is : " << std::exp(-tmp) << std::endl;
		return Kxx;
	}
	//---------------------------------------------------------------------
	//  The parameters of AomEKF are load.
	//---------------------------------------------------------------------
	void TrainGP()// std::vector<double> m_vNewR
	{
		size_t Len = m_vNewR.size();
		MatXX K(Len, Len);
		double DeltaF;
		for (size_t i = 0; i < Len; i++) {
			for (size_t j = 0; j < Len; j++) {
				if (i == j) {
					DeltaF = 1.0;
				}
				else {
					DeltaF = 0.0;
				}
				K(i, j) = KxxFun(m_vNewR[i], m_vNewR[j], DeltaF);
			}
		}
		m_K = K;
		m_invK = m_K.inverse();
	}
	//---------------------------------------------------------------------
	//  The new version, the time used is about 1 ms
	//---------------------------------------------------------------------
	std::vector<Vec4d> TestGP(const std::vector<Vec4d> & vNewV)
	{	// m_K, m_vNewR, m_vRads,  TestGPNewVer
		if (vNewV.size() != m_vNewR.size())
		{
			std::cout << "The length of m_vNewR and vNewV is not equal! " << std::endl;
		}
		MatXX matvNewV = CvVec4d2Mat(vNewV);
		MatXX yx = matvNewV.col(1);
		MatXX yy = matvNewV.col(2);
		MatXX yz = matvNewV.col(3);
		m_vDynCov.clear();
		MatXX Ks(1, m_vNewR.size());

		for (size_t i = 0; i < m_vRads.size(); i = i + m_GpRadRes) {
			double curR = m_vRads[i];
			for (size_t j = 0; j < m_vNewR.size(); j++) {
				Ks(0, j) = KxxFun(curR, m_vNewR[j], 0.0);
			}
			MatXX tmp = Ks * m_invK;	// 1XN * NXN  = 1XN
			MatXX vx = tmp * yx;	// 1XN * NX1
			MatXX vy = tmp * yy;	// 1XN * NX1
			MatXX vz = tmp * yz;	// 1XN * NX1

			Vec4d tmpVar;
			tmpVar(0) = curR;
			tmpVar(1) = (vx(0, 0) < 1e-3) ? 1e-3 : vx(0, 0);
			tmpVar(2) = (vy(0, 0) < 1e-3) ? 1e-3 : vy(0, 0);
			tmpVar(3) = (vz(0, 0) < 1e-3) ? 1e-3 : vz(0, 0);
			m_vDynCov.push_back(tmpVar);
		}
		return m_vDynCov;
	}
	//---------------------------------------------------------------------
	//  The new version, the time used is about 1 ms
	//---------------------------------------------------------------------
	std::vector<Vec4d> TestGP4Q(const std::vector<Vec4d> & vQ4V)
	{	// m_K, m_vNewR, m_vRads,  TestGPNewVer
		if (vQ4V.size() != m_vNewR.size())
		{
			std::cout << "The length of m_vNewR and vNewV is not equal! " << std::endl;
		}
		MatXX matvNewV = CvVec4d2Mat(vQ4V);
		MatXX yq1 = matvNewV.col(0);
		//std::cout << yq1 << std::endl;
		MatXX yq2 = matvNewV.col(1);
		MatXX yq3 = matvNewV.col(2);
		MatXX yq4 = matvNewV.col(3);
		m_vDq4Cov.clear();
		MatXX Ks(1, m_vNewR.size());

		for (size_t i = 0; i < m_vRads.size(); i = i + m_GpRadRes) {
			double curR = m_vRads[i];
			for (size_t j = 0; j < m_vNewR.size(); j++)
			{
				Ks(0, j) = KxxFun(curR, m_vNewR[j], 0.0);
			}
			MatXX tmp = Ks * m_invK;	// 1XN * NXN  = 1XN
			MatXX vq1 = tmp * yq1;	// 1XN * NX1
			MatXX vq2 = tmp * yq2;	// 1XN * NX1
			MatXX vq3 = tmp * yq3;	// 1XN * NX1
			MatXX vq4 = tmp * yq4;	// 1XN * NX1

			Vec4d tmpVar;
			double thrVal = 1e-3; // measure noise > 0.01, so change
			tmpVar(0) = (vq1(0, 0) < thrVal) ? thrVal : vq1(0, 0);
			tmpVar(1) = (vq2(0, 0) < thrVal) ? thrVal : vq2(0, 0);
			tmpVar(2) = (vq3(0, 0) < thrVal) ? thrVal : vq3(0, 0);
			tmpVar(3) = (vq4(0, 0) < thrVal) ? thrVal : vq4(0, 0);
			m_vDq4Cov.push_back(tmpVar);
		}
		//VecVec4dShow(m_vDq4Cov);
		return m_vDq4Cov;
	}
	//---------------------------------------------------------------------
	// Quadrant4  The new version, the time used is about 1 ms
	//---------------------------------------------------------------------
	std::vector<double> TestGPDouble(const std::vector<double> & vNewV)
	{	// m_K, m_vNewR, m_vRads,  TestGPNewVer
		if (vNewV.size() != m_vNewR.size())
		{
			std::cout << "The length of m_vNewR and vNewV is not equal! " << std::endl;
		}
		MatXX yx = CvVec2Mat(vNewV);
		std::vector<double> nVar;
		MatXX Ks(1, m_vNewR.size());
		for (size_t i = 0; i < m_vRads.size(); i = i + m_GpRadRes) {
			double curR = m_vRads[i];
			for (size_t j = 0; j < m_vNewR.size(); j++) {
				Ks(0, j) = KxxFun(curR, m_vNewR[j], 0.0);
			}
			MatXX tmp = Ks * m_invK;	// 1XN * NXN  = 1XN
			MatXX vx = tmp * yx;		// 1XN * NX1
			double tmpVar = (vx(0, 0) < 1e-2) ? 1e-2 : vx(0, 0);
			nVar.push_back(tmpVar);
		}
		return nVar;
	}
	//
	void TestGPInit()// m_K, m_vNewR, m_vRads,  TestGPNewVer
	{
		for (size_t i = 0; i < m_vRads.size(); i = i + m_GpRadRes) {
			Vec4d tmpVar;
			tmpVar(0) = m_vRads[i];
			tmpVar(1) = 1e-2;
			tmpVar(2) = 1e-2;
			tmpVar(3) = 1e-2;
			m_vDynCov.push_back(tmpVar);
			tmpVar(0) = 1e-2;
			m_vDq4Cov.push_back(tmpVar);// Quatant 4, more accurate
		}
	}
	//---------------------------------------------------------------------
	//  m_vEstCov are obtained. m_vEstCov = m_vDynCov + m_vMeaCov
	//---------------------------------------------------------------------
	void GetvEstCovs()
	{	//m_GpRadRes; m_vEstRads
		m_vEstCov.clear();
		m_vEstRads_Ptr->clear();
		size_t Len = m_vDynCov.size();
		for (size_t i = 0; i < Len; i++)
		{
			Vec4d mDyncov = m_vDynCov[i];
			Vec4d mMeacov = m_vMeaCov[i * m_GpRadRes];
			Vec4d mEstcov = mDyncov + mMeacov;
			mEstcov(0) = mDyncov(0);
			m_vEstCov.push_back(mEstcov);
			pcl::PointXY tmpR;
			tmpR.x = mDyncov(0);
			tmpR.y = 0.0;
			m_vEstRads_Ptr->points.push_back(tmpR);
		}
		m_KdvEstRads_ptr->setInputCloud(m_vEstRads_Ptr);
	}

	//---------------------------------------------------------------------
	//  All parameter load are plotted on screen.
	//---------------------------------------------------------------------
	void show()
	{
		std::cout << "The patameters of AomEKF is load. " << std::endl;
		std::cout << "---------------------------------------------------------------------------------" << std::endl;
		std::cout << "   m_isAdp          : " << m_isAdp << std::endl;
		std::cout << "   m_isRTM          : " << m_isRTM << std::endl;
		std::cout << "   m_StartID        : " << m_StartID << std::endl;
		std::cout << "   m_StartTF        : " << CTF2Pose(m_StartTF).transpose() << std::endl;
		std::cout << "   m_CorrectThr     : " << m_CorrectThr << std::endl;
		std::cout << "   m_TrainThr       : " << m_TrainThr << std::endl;
		std::cout << "   m_ModC           : " << m_ModC << std::endl;
		std::cout << "   m_CorrepMethod   : " << m_CorrepMethod << std::endl;
		std::cout << "   m_RegMaxIterNum  : " << m_RegMaxIterNum << std::endl;
		std::cout << "   m_PointSelMethod : " << m_PointSelMethod << std::endl;
		std::cout << "   m_GridRes        : " << m_GridRes << std::endl;
		std::cout << "   m_PtNum          : " << m_PtNum << std::endl;
		std::cout << "   m_MinR           : " << m_MinR << std::endl;
		std::cout << "   m_MaxR           : " << m_MaxR << std::endl;
		std::cout << "   m_dR             : " << m_dR << std::endl;
		std::cout << "   m_GpRadRes       : " << m_GpRadRes << std::endl;

		std::cout << "   m_MapRandDoRes   : " << m_MapRandomDownRes << std::endl;
		std::cout << "   m_CalTF          : " << "\n" << m_CalTF << std::endl;

		std::cout << "   m_K              : [" << m_K.rows() << ", " << m_K.cols() << "]" << std::endl;
		std::cout << "   m_invK           : [" << m_invK.rows() << ", " << m_invK.cols() << "]" << std::endl;
		std::cout << "   m_vRads          : " << m_vRads.size() << std::endl;
		std::cout << "   m_vNewR          : " << m_vNewR.size() << std::endl;
		std::cout << "   m_MotionCov      : " << m_MotionCov.transpose() << std::endl;
		std::cout << "   m_InitCov        : " << m_InitCov.transpose() << std::endl;

		std::cout << "   m_vMeaCov        : " << m_vMeaCov.size() << std::endl;
		std::cout << "   m_vDynCov        : " << m_vDynCov.size() << std::endl;
		std::cout << "   m_vEstCov        : " << m_vEstCov.size() << std::endl;
		std::cout << "   m_vStdCov        : " << m_vStdCov.size() << std::endl;

		std::cout << "   m_vGrdPose       : " << m_vGrdPose.size() << std::endl;
		std::cout << "   m_vImuPose       : " << m_vImuPose.size() << std::endl;
		std::cout << "   m_vIdx           : " << m_vIdx.size() << std::endl;
		std::cout << "   m_vSelIdx        : " << m_vSelIdx.size() << std::endl;
		std::cout << "   m_isUseDataRoot  : " << m_isUseDataRoot << std::endl;
		std::cout << "   m_MapRoot        : " << m_MapRoot << std::endl;
		std::cout << "   m_MapFile        : " << m_MapFile << std::endl;
		std::cout << "   m_DataRoot       : " << m_DataRoot << std::endl;
		std::cout << "   m_PcdRoot        : " << m_PcdRoot << std::endl;
		std::cout << "---------------------------------------------------------------------------------" << std::endl;
	}
	//---------------------------------------------------------------------
	//  The parameters of AomEKF are load.
	//---------------------------------------------------------------------
	void read()
	{
		std::string ParaFile = "AdpInEKFPara.txt";
		std::ifstream ifData;
		ifData.open(ParaFile);
		if (!ifData)
		{
			cout << "Cannot get the AdpInEKFPara.txt file!" << endl;
			exit(-1);
		}
		std::stringstream ss;
		std::string tmpStr;
		clear();
		while (!ifData.eof())
		{
			getline(ifData, tmpStr);
			if (tmpStr.empty())
			{
				continue;
			}
			if (tmpStr[0] == '#')
			{
				continue;
			}
			ss.clear();
			ss.str(tmpStr);
			std::string sHeader;
			ss >> sHeader;
			if (0 == sHeader.compare("MapRoot"))
			{
				ss >> m_MapRoot;
				continue;
			}
			if (0 == sHeader.compare("MapFile"))
			{
				ss >> m_MapFile;
				continue;
			}
			if (0 == sHeader.compare("isUseDataRoot"))
			{
				ss >> m_isUseDataRoot;
				continue;
			}
			if (0 == sHeader.compare("MapRandomDownRes"))
			{
				ss >> m_MapRandomDownRes;
				continue;
			}
			if (0 == sHeader.compare("CalibrationTF"))
			{
				std::vector<double> vTmpTQ;
				vTmpTQ.resize(7, 0.0); // tx ,ty , tz , qx , qy , qz , qw
				ss >> vTmpTQ[0] >> vTmpTQ[1] >> vTmpTQ[2] >> vTmpTQ[3] >> vTmpTQ[4] >> vTmpTQ[5] >> vTmpTQ[6];
				//char S[200] = " ";
				//sprintf_s(S,"%.6f, %.6f, %.6f, %.6f, %.6f, %.6f, %.6f", vTmpTQ[0],vTmpTQ[1],vTmpTQ[2],vTmpTQ[3],vTmpTQ[4],vTmpTQ[5],vTmpTQ[6]);
				//std::cout << S << std::endl;
				m_CalTF = CTQ2TF(vTmpTQ);
				continue;
			}
			if (0 == sHeader.compare("DataRoot"))
			{
				ss >> m_DataRoot;
				continue;
			}
			if (0 == sHeader.compare("PcdRoot"))
			{
				ss >> m_PcdRoot;
				continue;
			}
			if (0 == sHeader.compare("MotionCov"))
			{
				for (int i = 0; i < 6; i++)
				{
					ss >> m_MotionCov(i);
				}
				continue;
			}
			if (0 == sHeader.compare("InitCov"))
			{
				for (int i = 0; i < 6; i++)
				{
					ss >> m_InitCov[i];
				}
				continue;
			}
			if (0 == sHeader.compare("vStdCov"))
			{
				Vec4d tmpCov;
				ss >> tmpCov(0) >> tmpCov(1) >> tmpCov(2) >> tmpCov(3);
				m_vStdCov.push_back(tmpCov);
				continue;
			}
			if (0 == sHeader.compare("vMeaCov"))
			{
				Vec4d tmpCov;
				ss >> tmpCov(0) >> tmpCov(1) >> tmpCov(2) >> tmpCov(3);
				m_vMeaCov.push_back(tmpCov);
				continue;
			}
			if (0 == sHeader.compare("isAdp")) //m_isRTM
			{
				ss >> m_isAdp;
				continue;
			}
			if (0 == sHeader.compare("isRTM")) //m_isRTM
			{
				ss >> m_isRTM;
				continue;
			}
			if (0 == sHeader.compare("StartID"))
			{
				ss >> m_StartID;
				m_StartID = m_StartID - 1; // 2020-11-28
				continue;
			}
			if (0 == sHeader.compare("CorrectThr"))
			{
				ss >> m_CorrectThr;
				continue;
			}
			if (0 == sHeader.compare("TrainThr"))
			{
				ss >> m_TrainThr;
				continue;
			}
			if (0 == sHeader.compare("ModelC"))
			{
				ss >> m_ModC;
				continue;
			}
			if (0 == sHeader.compare("CorrepMethods"))
			{
				ss >> m_CorrepMethod;
				continue;
			}//
			if (0 == sHeader.compare("RegMaxIterNum"))
			{
				ss >> m_RegMaxIterNum;
				continue;
			}
			if (0 == sHeader.compare("SelPointMethods"))
			{
				ss >> m_PointSelMethod;
				continue;
			}
			if (0 == sHeader.compare("GridSize"))
			{
				ss >> m_GridRes;
				continue;
			}
			if (0 == sHeader.compare("PointNum"))
			{
				ss >> m_PtNum;
				continue;
			}
			if (0 == sHeader.compare("RadiusRange"))
			{
				ss >> m_MinR >> m_MaxR;
				continue;
			}
			if (0 == sHeader.compare("DeltaRadius"))
			{
				ss >> m_dR;
				continue;
			}
			if (0 == sHeader.compare("LocPoses"))
			{
				Vec6d GrdPose;
				Vec6d ImuPose;
				int tmpIdx;
				int tmpSel;
				ss >> tmpIdx >> tmpSel;
				for (int i = 0; i < 6; i++)
				{
					ss >> GrdPose(i);
				}
				for (int i = 0; i < 6; i++)
				{
					ss >> ImuPose(i);
				}
				m_vGrdPose.push_back(GrdPose);//m_vGrdPose
				m_vImuPose.push_back(ImuPose);
				m_vIdx.push_back(tmpIdx);
				m_vSelIdx.push_back(tmpSel);
			}
		}
	}

};

#endif
