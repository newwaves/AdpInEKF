#pragma once
#ifndef H_LOC_COM_FUN_H
#define H_LOC_COM_FUN_H

#include "stdafx.h"

//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
void SaveVecData(const std::string& FileName, const std::vector<double>& vRads)
{
	std::ofstream LocLog;
	LocLog.open(FileName.c_str());
	for (size_t i = 0; i < vRads.size(); i++)
	{
		LocLog << i << "  " << vRads[i] << std::endl;
	}
	LocLog.close();
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
int VecVec4dShow(const std::vector<Vec4d> & vNewV)
{
	for (size_t i = 0; i < vNewV.size(); i++)
	{
		std::cout << vNewV[i].transpose() << std::endl;
	}
	return 0;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Mat3d SkewD(const Vec3d& vA)
{
	Mat3d TmpTF = Mat3d::Zero();
	TmpTF(0, 1) = -vA(2);
	TmpTF(0, 2) = vA(1);
	TmpTF(1, 0) = vA(2);
	TmpTF(1, 2) = -vA(0);
	TmpTF(2, 0) = -vA(1);
	TmpTF(2, 1) = vA(0);
	return TmpTF;
}

inline
Mat6d AdjTF(const Mat4d& TF)
{
	Mat3d TmpR = TF.block<3, 3>(0, 0);
	Vec3d TmpT = TF.block<3, 1>(0, 3);
	Mat6d AdTF = Mat6d::Identity();
	AdTF.block<3, 3>(0, 0) = TmpR;
	AdTF.block<3, 3>(0, 3) = Mat3d::Zero();
	AdTF.block<3, 3>(3, 0) = SkewD(TmpT) * TmpR;
	AdTF.block<3, 3>(3, 3) = TmpR;
	return AdTF;
}
// function state =  Exp(epslion) % R, t
// R = expm(skew(epslion(1:3)));
// t = epslion(4:6);
// state = [R, t; 0 0 0 1];
// end
inline
Mat4d ExpFun(const Vec6d & D)
{
	Mat4d T = Mat4d::Identity();
	T.block<3, 3>(0, 0) = Mat3d::Identity() + SkewD(D.block<3, 1>(0, 0));
	T.block<3, 1>(0, 3) = D.block<3, 1>(3, 0);
	return T;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Vec3d CRot2Eul(const Mat3d& R) 		//	It is same to matlab 
{
	Vec3d E = Eigen::Vector3d::Zero();
	double sy = sqrt(R(0, 0)*R(0, 0) + R(1, 0)*R(1, 0));
	bool singular = (sy < 10e-10) ? true : false;
	Vec3d tEuler;
	if (!singular) {
		tEuler(0) = atan2(R(2, 1), R(2, 2));	//	x
		tEuler(1) = atan2(-R(2, 0), sy);		//	y
		tEuler(2) = atan2(R(1, 0), R(0, 0));	//	z
	}
	else {
		tEuler(0) = atan2(-R(1, 2), R(1, 1));
		tEuler(1) = atan2(-R(2, 0), sy);
		tEuler(2) = 0;
	}
	//std::cout << "tEuler<Z-Y-X> is :\n" << tEuler.transpose() << std::endl;
	E(0) = tEuler(2);
	E(1) = tEuler(1);
	E(2) = tEuler(0);
	return E;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Mat3d CEul2Rot(const Vec3d& theta) //	Z -> Y -> X	
{
	double yaw = theta(0);		// z
	double pitch = theta(1);
	double roll = theta(2);
	Eigen::AngleAxisd yawAngle(yaw, Eigen::Vector3d::UnitZ());		//	Z
	Eigen::AngleAxisd pitchAngle(pitch, Eigen::Vector3d::UnitY());	//	Y
	Eigen::AngleAxisd rollAngle(roll, Eigen::Vector3d::UnitX());	//	X
	Eigen::Quaterniond q = yawAngle * pitchAngle * rollAngle;
	Mat3d R = q.matrix();
	return R;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Mat4d CPose2TF(const Vec6d& Pose)
{
	Mat4d tmpTF = Eigen::Matrix4d::Identity();
	tmpTF.block<3, 3>(0, 0) = CEul2Rot(Pose.block<3, 1>(3, 0));
	tmpTF.block<3, 1>(0, 3) = Pose.block<3, 1>(0, 0);
	return tmpTF;
}
inline
Vec6d CTF2Pose(const Mat4d& TF)
{
	Vec6d Pose;
	Pose.block<3, 1>(0, 0) = TF.block<3, 1>(0, 3);
	Pose.block<3, 1>(3, 0) = CRot2Eul(TF.block<3, 3>(0, 0));
	return Pose;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Vec6d CPose2State(const Vec6d& Pose) // x, y, z, az, ay, ax
{
	Vec6d State;	//	ax, ay, az, x, y, z
	State(0) = Pose(5);
	State(1) = Pose(4);
	State(2) = Pose(3);
	State(3) = Pose(0);
	State(4) = Pose(1);
	State(5) = Pose(2);
	return State;
}
inline
Vec6d CState2Pose(const Vec6d& State) // ax, ay, az, x, y, z
{
	Vec6d Pose;		// x, y, z, az, ay, ax
	Pose(5) = State(0);
	Pose(4) = State(1);
	Pose(3) = State(2);
	Pose(0) = State(3);
	Pose(1) = State(4);
	Pose(2) = State(5);
	return Pose;
}
inline
Mat4d CState2TF(const Vec6d& State)
{
	return CPose2TF(CState2Pose(State));
}
inline
Vec6d CTF2State(const Mat4d& TF)
{
	return CPose2State(CTF2Pose(TF));
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
MatXX CStdVec2Mat(const std::vector<double>& vTmpV)
{
	size_t Len = vTmpV.size();
	MatXX matRV(Len, 1);
	for (size_t i = 0; i < Len; i++)
	{
		matRV(i, 0) = vTmpV[i];
	}
	return matRV;
}
//
inline
MatXX CvVec2Mat(const std::vector<double>& vTmpV)
{
	size_t Len = vTmpV.size();
	MatXX matRV(Len, 1);
	for (size_t i = 0; i < Len; i++)
	{
		matRV(i, 0) = vTmpV[i];
	}
	return matRV;
}
//
inline
MatXX CvVec4d2Mat(const std::vector<Vec4d>& vTmpV)
{
	size_t Len = vTmpV.size();
	MatXX matRV(Len, 4);
	for (size_t i = 0; i < Len; i++)
	{
		matRV(i, 0) = vTmpV[i](0);
		matRV(i, 1) = vTmpV[i](1);
		matRV(i, 2) = vTmpV[i](2);
		matRV(i, 3) = vTmpV[i](3);
	}
	return matRV;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
std::vector<Vec4d> CvDouble2vVec4d(const std::vector<double>& vData)
{
	std::vector<Vec4d> vNewV;
	for (size_t i = 0; i < vData.size(); i++)
	{
		Vec4d tmPt;
		tmPt(0) = 0.0;
		tmPt(1) = vData[i];
		tmPt(2) = vData[i];
		tmPt(3) = vData[i];
		vNewV.push_back(tmPt);
	}
	return vNewV;
}
inline
std::vector<Vec4d> CvvDD2vVec4d(const std::vector<std::vector<double>>& vvData)
{
	std::vector<Vec4d> vNewV;
	for (size_t i = 0; i < vvData[0].size(); i++)
	{
		Vec4d tmPt;
		tmPt(0) = vvData[0][i];
		tmPt(1) = vvData[1][i];
		tmPt(2) = vvData[2][i];
		tmPt(3) = vvData[3][i];
		vNewV.push_back(tmPt);
	}
	return vNewV;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
void MatSizeShow(const MatXX &M)
{
	std::cout << "[" << M.rows() << ", " << M.cols() << "]" << std::endl;
}
//
inline
void MatShow(const MatXX &M)
{
	std::cout << "-----------------------------------" << std::endl;
	std::cout << M << std::endl;
	std::cout << "-----------------------------------" << std::endl;
}
//
inline
void vVecShow(const std::vector<Vec4d>& vVecM)
{
	size_t Len = vVecM.size();
	for (size_t i = 0; i < Len; i++)
	{
		std::cout << vVecM[i].transpose() << std::endl;
	}
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
double SEdistT(const Vec6d& GrdPose, const Vec6d& LocPose)
{
	Vec3d tmpA;
	tmpA(0) = GrdPose(0);
	tmpA(1) = GrdPose(1);
	tmpA(2) = GrdPose(2);
	Vec3d tmpB;
	tmpB(0) = LocPose(0);
	tmpB(1) = LocPose(1);
	tmpB(2) = LocPose(2);
	return (tmpA - tmpB).norm();
}
inline
double SEdistR(const Vec6d& GrdPose, const Vec6d& LocPose)
{
	Vec3d tmpA;
	tmpA(0) = GrdPose(3);
	tmpA(1) = GrdPose(4);
	tmpA(2) = GrdPose(5);
	Mat3d ATF = CEul2Rot(tmpA);
	Vec3d tmpB;
	tmpB(0) = LocPose(3);
	tmpB(1) = LocPose(4);
	tmpB(2) = LocPose(5);
	Mat3d BTF = CEul2Rot(tmpB);
	Mat3d dTF = ATF.inverse() * BTF;
	return std::acos((dTF.trace() - 1.0) / 2.0);
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
double warpTo2Pi(const double& lambda)
{
	bool tmpB = lambda > 0.0;
	double tmpV = 0.0;
	tmpV = std::fmod(lambda, 2.0 * M_PI);
	if ((lambda == 0.0) && (tmpB))
	{
		tmpV = 2.0 * M_PI;
	}
	return tmpV;
}
//
inline
double warpToPi(const double& lambda)
{
	double tmpV = lambda;
	if ((lambda < -M_PI) || (M_PI < lambda))
	{
		tmpV = warpTo2Pi(lambda + M_PI) - M_PI;
	}
	return tmpV;
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
template<typename PointT>
inline
double Norm(const PointT &Pt)
{
	return std::sqrt(Pt.x * Pt.x + Pt.y * Pt.y + Pt.z * Pt.z);
}
template<typename TypeT>
inline
TypeT CalMean(const std::vector<TypeT>& vData)
{
	TypeT sum = std::accumulate(vData.begin(), vData.end(), (double)0.0f); // 
	return sum / ((double)vData.size());
}
template<typename TypeT>
inline
TypeT CalVar(const std::vector<TypeT>& vData)
{
	TypeT var = 0.0;
	TypeT mu = CalMean(vData);
	for (size_t i = 0; i < vData.size(); i++)
	{
		var = var + std::pow(vData[i] - mu, 2);
	}
	return var / (vData.size() - 1.0f);
}

//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
inline
Eigen::Matrix4d CTQ2TF(const std::vector<double>& vTQ) {
	Eigen::Matrix4d tfrom = Eigen::Matrix4d::Identity();
	tfrom(0, 3) = vTQ[0];
	tfrom(1, 3) = vTQ[1];
	tfrom(2, 3) = vTQ[2];
	tfrom(3, 3) = 1.0;
	Eigen::Quaterniond q;	//	<x,y,z,w>
	q.x() = vTQ[3];
	q.y() = vTQ[4];
	q.z() = vTQ[5];
	q.w() = vTQ[6];
	Eigen::Matrix3d R = q.normalized().toRotationMatrix();
	tfrom.block<3, 3>(0, 0) = R;
	return tfrom;
}
//----------------------------------------------------------------------------------------
//	
//----------------------------------------------------------------------------------------
inline double CAng2Rad(const double  Ang) { return Ang * (M_PI / 180); }
inline double CRad2Ang(const double  Rad) { return Rad * (180 / M_PI); }

//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
void RandomDownSample(const pcl::PointCloud<pcl::PointXYZ>::Ptr & InaPtr,
	pcl::PointCloud<pcl::PointXYZ>::Ptr & OutPtr,
	const double Res) {
	OutPtr->points.clear();
	for (size_t i = 0; i < InaPtr->points.size(); i++) {
		if (rand() / double(RAND_MAX) <= Res) {
			OutPtr->points.push_back(InaPtr->points[i]);
		}
	}
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->points.size();
	OutPtr->height = 1;
}
//----------------------------------------------------------------------------------------
//	
//----------------------------------------------------------------------------------------
inline
void EstHdlNormalFalse(const pcl::PointCloud<pcl::PointXYZ>::Ptr& Ina_ptr,
	pcl::PointCloud<pcl::PointNormal>::Ptr & XYZNor_ptr) {
	pcl::PointNormal tPoint;
	for (int i = 0; i < Ina_ptr->size(); i++) {
		if (!pcl_isfinite(Ina_ptr->points[i].x) ||
			!pcl_isfinite(Ina_ptr->points[i].y) ||
			!pcl_isfinite(Ina_ptr->points[i].z))
		{
			continue;
		}
		tPoint.x = Ina_ptr->points[i].x;
		tPoint.y = Ina_ptr->points[i].y;
		tPoint.z = Ina_ptr->points[i].z;
		tPoint.normal_x = 0.0;
		tPoint.normal_y = 0.0;
		tPoint.normal_z = 0.0;
		tPoint.curvature = 0;
		XYZNor_ptr->push_back(tPoint);
	}
	XYZNor_ptr->width = XYZNor_ptr->size();
	XYZNor_ptr->height = Ina_ptr->height;
	XYZNor_ptr->is_dense = Ina_ptr->is_dense;
	XYZNor_ptr->sensor_orientation_ = Ina_ptr->sensor_orientation_;
	XYZNor_ptr->sensor_origin_ = Ina_ptr->sensor_origin_;
	XYZNor_ptr->header = Ina_ptr->header;
}

//----------------------------------------------------------------------------------------
//	
//----------------------------------------------------------------------------------------
inline
void CNormalToXYZ(const pcl::PointCloud<pcl::PointNormal>::Ptr& PCNormal, pcl::PointCloud<pcl::PointXYZ>::Ptr& PCXYZ)
{
	PCXYZ->clear();
	pcl::PointXYZ tmpPt;
	// Iterate over each point
	for (size_t i = 0; i < PCNormal->size(); ++i) {
		tmpPt.x = PCNormal->points[i].x;
		tmpPt.y = PCNormal->points[i].y;
		tmpPt.z = PCNormal->points[i].z;
		PCXYZ->push_back(tmpPt);
	}
	PCXYZ->width = PCNormal->width;
	PCXYZ->height = PCNormal->height;
	PCXYZ->is_dense = PCNormal->is_dense;
}
//------------------------------------------------------------------------------------------------
// samplingWithoutReplacement Randomly generate K unique numbers from [1, ..., N]. rp = randperm(N);
//------------------------------------------------------------------------------------------------
inline
std::vector<int> randperm(const int Num)
{
	std::vector<int> numbres;
	for (int i = 0; i<Num; i++)
	{
		numbres.push_back(i);
	}
	std::random_shuffle(numbres.begin(), numbres.end());
	return numbres;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr DownRandom(const pcl::PointCloud<pcl::PointXYZ>::Ptr & InaPtr, const double Res) {
	pcl::PointCloud<pcl::PointXYZ>::Ptr OutPtr(new pcl::PointCloud<pcl::PointXYZ>);
	for (size_t i = 0; i < InaPtr->points.size(); i++) {
		if (rand() / double(RAND_MAX) <= Res) {
			OutPtr->points.push_back(InaPtr->points[i]);
		}
	}
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->points.size();
	OutPtr->height = 1;
	return OutPtr;
}
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr DownRandPermP(const pcl::PointCloud<pcl::PointXYZ>::Ptr & InaPtr, const double Res) {
	int PtsNum = InaPtr->points.size();
	std::vector<int> vNum = randperm(PtsNum);
	int numK = std::round(PtsNum * Res);
	pcl::PointCloud<pcl::PointXYZ>::Ptr OutPtr(new pcl::PointCloud<pcl::PointXYZ>);
	for (size_t i = 0; i < numK; i++) {
		OutPtr->points.push_back(InaPtr->points[vNum[i]]);
	}
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->points.size();
	OutPtr->height = 1;
	return OutPtr;
}
inline
pcl::PointCloud<pcl::PointNormal>::Ptr DownRandPermPN(const pcl::PointCloud<pcl::PointNormal>::Ptr & InaPtr, const double Res) {
	int PtsNum = InaPtr->points.size();
	std::vector<int> vNum = randperm(PtsNum);
	int numK = std::round(PtsNum * Res);
	pcl::PointCloud<pcl::PointNormal>::Ptr OutPtr(new pcl::PointCloud<pcl::PointNormal>);
	for (size_t i = 0; i < numK; i++) {
		OutPtr->points.push_back(InaPtr->points[vNum[i]]);
	}
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->points.size();
	OutPtr->height = 1;
	return OutPtr;
}

inline
pcl::PointCloud<pcl::PointNormal>::Ptr DownRandomPN(const pcl::PointCloud<pcl::PointNormal>::Ptr & InaPtr, const double Res) {
	pcl::PointCloud<pcl::PointNormal>::Ptr OutPtr(new pcl::PointCloud<pcl::PointNormal>);
	for (size_t i = 0; i < InaPtr->points.size(); i++) {
		if (rand() / double(RAND_MAX) <= Res) {
			OutPtr->points.push_back(InaPtr->points[i]);
		}
	}
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->points.size();
	OutPtr->height = 1;
	return OutPtr;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr DownGird(const pcl::PointCloud<pcl::PointXYZ>::Ptr &cloud, const double  &dGridSize)
{
	if (dGridSize < 0)   // do not subsampling.
	{
		return NULL;
	}
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_subsampled(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::VoxelGrid<pcl::PointXYZ> Voxel_filter;
	Voxel_filter.setLeafSize(dGridSize, dGridSize, dGridSize);
	Voxel_filter.setInputCloud(cloud);
	Voxel_filter.filter(*cloud_subsampled);

	cloud_subsampled->is_dense = cloud->is_dense;
	cloud_subsampled->sensor_origin_ = cloud->sensor_origin_;
	cloud_subsampled->sensor_orientation_ = cloud->sensor_orientation_;
	cloud_subsampled->header = cloud->header;
	cloud_subsampled->width = cloud_subsampled->size();
	cloud_subsampled->height = 1;
	return cloud_subsampled;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr LimitRange(const pcl::PointCloud<pcl::PointXYZ>::Ptr &cloud, const double& MinR, const double& MaxR)
{
	if ((MinR < 0.0) || (MaxR < MinR))   // do not subsampling.
	{
		return NULL;
	}
	pcl::PointCloud<pcl::PointXYZ>::Ptr CloudOut_Ptr(new pcl::PointCloud<pcl::PointXYZ>);
	size_t Len = cloud->points.size();
	for (size_t i = 0; i < Len; i++)
	{
		pcl::PointXYZ tmpt = cloud->points[i];
		double tmpR = std::sqrt(tmpt.x * tmpt.x + tmpt.y * tmpt.y + tmpt.z * tmpt.z);
		if ((tmpR < MinR) || (tmpR > MaxR) || (tmpt.z < -4.0) || (tmpt.z > 4.0))
		{
			continue;
		}
		CloudOut_Ptr->points.push_back(tmpt);
	}
	CloudOut_Ptr->is_dense = cloud->is_dense;
	CloudOut_Ptr->sensor_origin_ = cloud->sensor_origin_;
	CloudOut_Ptr->sensor_orientation_ = cloud->sensor_orientation_;
	CloudOut_Ptr->header = cloud->header;
	CloudOut_Ptr->width = CloudOut_Ptr->size();
	CloudOut_Ptr->height = 1;
	return CloudOut_Ptr;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------
inline
pcl::PointCloud<pcl::PointNormal>::Ptr RemoveNaNFromPC(const pcl::PointCloud<pcl::PointNormal>::Ptr & InaPtr)
{
	pcl::PointCloud<pcl::PointNormal>::Ptr OutPtr(new pcl::PointCloud<pcl::PointNormal>);
	for (size_t i = 0; i < InaPtr->points.size(); i++)
	{
		pcl::PointNormal tmpPt = InaPtr->points[i];

		if ((!pcl_isfinite(tmpPt.x)) || (!pcl_isfinite(tmpPt.y)) || (!pcl_isfinite(tmpPt.z))
			|| (!pcl_isfinite(tmpPt.normal_x)) || (!pcl_isfinite(tmpPt.normal_y)) || (!pcl_isfinite(tmpPt.normal_z)))
		{
			continue;
		}
		OutPtr->points.push_back(tmpPt);
	}
	OutPtr->header = InaPtr->header;
	OutPtr->width = OutPtr->size();
	OutPtr->height = 1;
	OutPtr->is_dense = InaPtr->is_dense;
	OutPtr->sensor_orientation_ = InaPtr->sensor_orientation_;
	OutPtr->sensor_origin_ = InaPtr->sensor_origin_;
	return OutPtr;
}
//------------------------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------------------------


inline
pcl::PointCloud<pcl::PointXYZ>::Ptr SelSubPtsP2P(const pcl::PointCloud<pcl::PointXYZ>::Ptr& fullPC, const std::vector<int> &indices)
{
	pcl::PointCloud<pcl::PointXYZ>::Ptr partPC(new pcl::PointCloud<pcl::PointXYZ>);
	if (indices.size() == fullPC->points.size())
	{
		return fullPC;
	}
	// Iterate over each point
	for (size_t i = 0; i < indices.size(); ++i)
	{
		partPC->push_back(fullPC->points[indices[i]]);
	}
	// Allocate enough space and copy the basics
	partPC->header = fullPC->header;
	partPC->width = partPC->size();
	partPC->height = 1;
	partPC->is_dense = fullPC->is_dense;
	partPC->sensor_orientation_ = fullPC->sensor_orientation_;
	partPC->sensor_origin_ = fullPC->sensor_origin_;
	return partPC;
}
inline
pcl::PointCloud<pcl::PointXYZ>::Ptr SubMapP2P(pcl::search::KdTree<pcl::PointXYZ>::Ptr & NormalMapSearch_ptr,
	const pcl::PointCloud<pcl::PointXYZ>::Ptr& ptMap, const Eigen::Matrix4d& PreTF)
{
	pcl::PointXYZ OrgPt;
	OrgPt.x = PreTF(0, 3);
	OrgPt.y = PreTF(1, 3);
	OrgPt.z = PreTF(2, 3);
	double Raidus = 50.0;

	std::vector<int>  vIdx;
	std::vector<float> k_Dist;
	unsigned int max_nn;
	NormalMapSearch_ptr->radiusSearch(OrgPt, Raidus, vIdx, k_Dist);

	pcl::PointCloud<pcl::PointXYZ>::Ptr Tmp(new pcl::PointCloud<pcl::PointXYZ>);
	Tmp = SelSubPtsP2P(ptMap, vIdx);
	return Tmp;
}
//---------------------------------------------------------------------------------------
//	savePCDFileBinaryCompressed fast
//---------------------------------------------------------------------------------------
inline
int SaveHdlPCD(const std::string &FileName,
	const std::string & MainFolder,
	const pcl::PointCloud<pcl::PointXYZ>::Ptr &SaveHdlPtr,
	const unsigned nFrm) {
	char PLYDir[200] = "\0";
	sprintf_s(PLYDir, "%s\\%sPCD\\", MainFolder.c_str(), FileName.c_str());
	if (_access(PLYDir, 0) != 0) {
		if (_mkdir(PLYDir) != 0) {
			std::cout << "Error : Output Folder is not Created!" << std::endl;
			exit(-1);
		}
	}
	char PLYName[200] = "\0";
	sprintf_s(PLYName, "%s%s%06d.pcd", PLYDir, FileName.c_str(), nFrm);
	pcl::io::savePCDFileBinaryCompressed(PLYName, *SaveHdlPtr);
	return 1;
}
void SaveVec6dPose(const std::string& FileName, const std::vector<Vec6d>& vLocPose)
{
	std::ofstream LocLog;
	LocLog.open(FileName.c_str());
	for (size_t i = 0; i < vLocPose.size(); i++)
	{
		LocLog << i << "  " << vLocPose[i].transpose() << std::endl;
	}
	LocLog.close();
}
//-----------------------------------------------------------------
//
//-----------------------------------------------------------------
#endif

