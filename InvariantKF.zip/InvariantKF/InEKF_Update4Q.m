function [Xk, Ck] = InEKF_Update4Q(kdMap, ptMap, ptHdl, Cbk, XbkTF, ParaS)

coresTF = ParaS.CorresTF;
[~, vZk, vMapPts, ~] = FindCorrespondences(kdMap, ptMap, ptHdl, coresTF, 1, ParaS.CorrectThr);

% added 2020-04-30
if size(vMapPts, 1) > 20   % the prediction value of observed points
    % right - invariant
    vZbk = [vZk, ones(size(vZk, 1), 1)];
    vtmpPts = XbkTF * vZbk';
    vZbk = vtmpPts(1:3, :)';
    
    %%
    if ParaS.isAdp == 1
        Md = createns( ParaS.Cov(:,1) ); % Md = ParaS.Md;
        vRs = sqrt(vZk(:,1).^2 + vZk(:,2).^2 + vZk(:,3).^2);
        vIdx = knnsearch(Md, vRs, 'k', 1);
    else
        Qk = diag(ParaS.Cov(2:4));  % 2020-05-07
    end

    eState = eye(4); %ParaS.errorS; %
    for i = 1 : 1 : size(vZbk,1)
        if ParaS.isAdp == 1
                Radius = norm(vZk(i,:)); % vRs(i)
                if Radius < ParaS.RadiusRange(1)
                    continue;
                else
                    idx = vIdx(i);
                    idxquat = isQuat(vZk(i,:));
                    Qk = diag( ParaS.QuatCov(idx, (idxquat-1) * 3 + 1 : idxquat * 3) );
                end
        end
        Hx = [skew(vMapPts(i,:)), -eye(3)]; % right2
        
        Sk = Hx * Cbk * Hx' + Qk;
        Kk = Cbk * Hx' / Sk;
        eState = Exp(Kk * (vZbk(i,:)' - vMapPts(i,:)')) * eState; % right2
        Cbk = (eye(6) - Kk * Hx) * Cbk;
    end
    %-----------------------------------------------------
    Xk = eState * XbkTF; % right-invariant
    Ck = Cbk;
    %-----------------------------------------------------
else
    Xk = XbkTF;
    Ck = Cbk;
end
end
%% ParaS.MeaNoise(1:2:end,:);
function Qk = QuatCov(Pt, idx, ParaS)
if (Pt(1)>=0) && (Pt(2)>=0) % 1
    QIdx = 1;
end
if (Pt(1)<0) && (Pt(2)>=0) % 2
    QIdx = 2;
end
if (Pt(1)<0) && (Pt(2)<0) % 3     
   QIdx = 3;
end
if (Pt(1)>=0) && (Pt(2)<0) % 4
   QIdx = 4;
end
QIdx = QIdx + 1;
Qk = diag( ParaS.modelC .* ([ParaS.Dynamic(idx,QIdx),ParaS.Dynamic(idx,QIdx),ParaS.Dynamic(idx,QIdx)] +  ParaS.MeaNoise(idx,2:4)));
end
%
function QIdx = isQuat(Pt)
if (Pt(1)>=0) && (Pt(2)>=0) % 1
    QIdx = 1;
end
if (Pt(1)<0) && (Pt(2)>=0) % 2
    QIdx = 2;
end
if (Pt(1)<0) && (Pt(2)<0) % 3     
   QIdx = 3;
end
if (Pt(1)>=0) && (Pt(2)<0) % 4
   QIdx = 4;
end
end
%%
function state =  Exp(epslion) % R, t
R = expm(skew(epslion(1:3)));
t = epslion(4:6);
state = [R, t; 0 0 0 1];
end