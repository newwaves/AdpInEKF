function GPRYN = TestGP4Q(K, vNewR, vNewVQ1, vNewVQ2, vNewVQ3, vNewVQ4, vRads)
% 2020-10-20 New version, Fast version!!!!!!!
x = vNewR';
invK = eye(size(x,2)) / K;

yq1 = vNewVQ1(:,1)';
yq2 = vNewVQ2(:,1)';
yq3 = vNewVQ3(:,1)';
yq4 = vNewVQ4(:,1)';

vVx = [];
vVy = [];
vVz = [];
vVw = [];
dN = 2;  % resolution : 0.1m  * dN = 0.2m res
for n = 1 : dN : length(vRads)
    xs = vRads(n);
    Kss = K(1,1);
    %     Ks = zeros(1,size(x,2));
    %     for i = 1 : 1 : size(x,2)
    %         Ks(i) = KxxFunN(xs, x(i), 0);
    %     end
    Ks = 1.0e-04 .* exp( - (xs - x).^2 ./ 8 ); % modified@2020-04-06
    
    tmp = Ks * invK;
    Vx = tmp * yq1';
    Vy = tmp * yq2';
    Vz = tmp * yq3';
    Vw = tmp * yq4';
    
    vVx = [vVx, Vx];
    vVy = [vVy, Vy];
    vVz = [vVz, Vz];
    vVw = [vVw, Vw];
end

% add in 2020-04-05, the variance is not negative!!
THRV = 1e-4; %  adjusting the meanoise >= 0.01
vVx(vVx < THRV) = THRV;
vVy(vVy < THRV) = THRV;
vVz(vVz < THRV) = THRV;
vVw(vVw < THRV) = THRV;
%
GPRYN = [vRads(1:dN:end), vVx',vVy',vVz',vVw']; % vRads, q1 q2 q3 q4

isShow = 0;
if isShow == 1
    GpCov = GPRYN;
    figure;hold on;grid on;
    plot(GpCov(:,1),GpCov(:,2),'r.-');
    plot(vNewR(:,1),vNewVQ1(:,1),'bh-');
    figure;hold on;grid on;
    plot(GpCov(:,1),GpCov(:,3),'r.-');
    plot(vNewR(:,1),vNewVQ2(:,2),'bh-');
    figure;hold on;grid on;
    plot(GpCov(:,1),GpCov(:,4),'r.-');
    plot(vNewR(:,1),vNewVQ3(:,3),'bh-');
	figure;hold on;grid on;
    plot(GpCov(:,1),GpCov(:,5),'r.-');
    plot(vNewR(:,1),vNewVQ4(:,3),'bh-');
end
end