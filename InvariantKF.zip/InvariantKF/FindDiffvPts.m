function [vPtsP2P, vPtsP2L] = FindDiffvPts(kdMap, ptMap, ptOrg, trTF)

%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   for Aom variance matrix deterimining
vtranPts = myRigidTransform(ptOrg.Location, trTF(1:3,1:3), trTF(1:3,end));
%%
%Find the correspondence
[indices, dists] = knnsearch(kdMap, vtranPts, 'dist','euclidean');
% Remove outliers
keepInlierA = false(ptOrg.Count, 1);
[~, idx] = sort(dists);
upperBound = length(find(dists < 100)); % very important parameters 2020-05-04
keepInlierA(idx(1:upperBound)) = true;
inlierIndicesB = indices(keepInlierA);
vTraPts = vtranPts(keepInlierA,:); % Here is different from CorrectStepModel
vHdlPts = ptOrg.Location(keepInlierA,:);
vMapPts = ptMap.Location(inlierIndicesB,:);
vMapNor = ptMap.Normal(inlierIndicesB,:);
%%
validLen = size(vHdlPts,1);
vDPts = zeros(validLen,3); % [x y z]
vDist = zeros(validLen,2); % [pointTopoint, pointToplane]

vDPts = vTraPts - vMapPts;
tmpP2P = sqrt(vDPts(:,1).^2 + vDPts(:,2).^2 + vDPts(:,3).^2);
tmpNN = sqrt(vMapNor(:,1).^2 + vMapNor(:,2).^2 + vMapNor(:,3).^2);
tmpP2PL = abs(sum(vDPts .* vMapNor, 2) ./ tmpNN);
vDist = [tmpP2P, tmpP2PL];
%--------------------------------------------------------------------------
vIdxP2P = vDist(:,1) >= 0.8; 
vIdxP2L = vDist(:,2) >= 0.8; 
vPtsP2P = vHdlPts(vIdxP2P, :);
vPtsP2L = vHdlPts(vIdxP2L, :);
%

end
