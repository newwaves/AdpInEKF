function K = TrainGPN(vNewR)
Len = length(vNewR);    
x = vNewR; % 1 X N
K = zeros(Len,Len);
for i = 1 : 1 : Len
    for j = 1 : 1 : Len
        if i == j
            DeltaF = 1;
        else
            DeltaF = 0;
        end
        K(i,j) = KxxFunN(x(i),x(j), DeltaF);
    end
end
end