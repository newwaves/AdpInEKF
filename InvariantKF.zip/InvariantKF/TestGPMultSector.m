function [cGPR, vGprTe, vGprTr] = TestGPMultSector(K, vNewR, cNewVQ, vRads, vMeaNiose, modelC)
% 2020-10-20 New version, Fast version!!!!!!!
cGPR = {};
vGprTe = vRads(1:2:end, :); % for displaying the dynamic nosie
vGprTr = vNewR;             % for displaying the dynamic nosie
for n = 1 : 1 : length(cNewVQ)
    tmpNewQ = cNewVQ{n};
    tmpGPR = TestGP1Q(K, vNewR, tmpNewQ, vRads);
    %
    StateGPR = modelC .* ([tmpGPR(:,2),tmpGPR(:,2),tmpGPR(:,2)] + vMeaNiose(:,2:4));
    %
    cGPR{end+1} = [tmpGPR(:,1), StateGPR];
    vGprTe = [vGprTe, tmpGPR(:,2)];
    vGprTr = [vGprTr, tmpNewQ];
end

isShow = 0;
if isShow == 1
    for n = 1 : 1 : length(cGPR)
        tmpGPR = cGPR{n};
        tmpRaw = cNewVQ{n};
        figure;hold on;grid on;
        plot(tmpGPR(:,1),tmpGPR(:,2),'r.-');
        plot(vNewR(:,1),tmpRaw(:,1),'bh-');
    end
end
end

%%
function GPR = TestGP1Q(K, vNewR, vNewVQ, vRads)
% 2020-10-20 New version, Fast version!!!!!!!
x = vNewR';
invK = eye(size(x,2)) / K;
yq1 = vNewVQ(:,1)';
vVx = [];
dN = 2;  % resolution : 0.1m  * dN = 0.2m res
for n = 1 : dN : length(vRads)
    xs = vRads(n);
    Kss = K(1,1);
    Ks = 1.0e-04 .* exp( - (xs - x).^2 ./ 8 ); % modified@2020-04-06    
    tmp = Ks * invK;
    Vx = tmp * yq1';
    vVx = [vVx, Vx];
end
% add in 2020-04-05, the variance is not negative!!
THRV = 1e-4; %  adjusting the meanoise >= 0.01
vVx(vVx < THRV) = THRV;
%
GPR = [vRads(1:dN:end), vVx']; % vRads, q1 q2 q3 q4
isShow = 0;
if isShow == 1
    GpCov = GPR;
    figure;hold on;grid on;
    plot(GpCov(:,1),GpCov(:,2),'r.-');
    plot(vNewR(:,1),vNewVQ1(:,1),'bh-');
end
end