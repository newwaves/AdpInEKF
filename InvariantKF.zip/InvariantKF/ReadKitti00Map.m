
RootDir = 'pcMap';
MapName = fullfile(RootDir, 'HDMap.pcd');  %   read map
ptMap = pcread( MapName );                 %   read map
MapRandomDownRes = 0.9;
ptMap = pcdownsample(ptMap, 'random', MapRandomDownRes); % 2020-11-12 0.2 Sparse

% figure;hold on;grid on;
% pcshow(ptMap);
% xlabel('x');ylabel('y');zlabel('z');
% title('Map');
ptMapShow = pcdownsample(ptMap, 'gridAverage', 1.0); % for display
kdMap = createns(ptMap.Location);
