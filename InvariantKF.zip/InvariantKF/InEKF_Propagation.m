function [XbkTF, Gx, Gu] = InEKF_Propagation( nFrm, OdometryPose, Xk_1, ParaS )

if ParaS.isFirst == 1  %nFrm == 1
    XbkTF = Xk_1; % [R, t; 0 0 0 1]
    Gx = eye(6);
    Gu = zeros(6,6);
else
    CurOdometryPose = OdometryPose(nFrm,:);
    PreOdometryPose = OdometryPose(nFrm - ParaS.dFrm,:); %  2021-01-25
    PreTF = CPose2TF(PreOdometryPose') * ParaS.CalTF; % convert to LiDAR system
    CurTF = CPose2TF(CurOdometryPose') * ParaS.CalTF;
    Uk = PreTF \ CurTF; % inv(PreTF) * CurTF;

    XbkTF = Xk_1 * Uk;  % X * U
    Gx = eye(6);
    Gu = Adjoint(XbkTF);
end
tmpPose = CTF2Pose(XbkTF);
TmpQ = eul2quat(tmpPose(4:6)');
TmpR = quat2rotm(TmpQ);
TmpR = eul2rotm(rotm2eul(TmpR));
TmpT = XbkTF(1:3,end);
XbkTF = [TmpR,TmpT;0 0 0 1];
end
