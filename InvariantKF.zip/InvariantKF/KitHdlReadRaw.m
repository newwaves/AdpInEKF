function [ptHdl,ptOrg,HdlData] = KitHdlReadRaw(nFrm, HdlRoot, GridRes, RadiusRange, isRandom)

FullName = fullfile( HdlRoot, sprintf('%06d.bin', nFrm) );
if ~exist( FullName, 'file')
    error('Not exist this file!');
end
fid = fopen(FullName,'rb');
Hdl = fread(fid,[4 inf],'single')';
fclose(fid);
vHdlIdx = Hdl(:,3) > -4;
Hdl = Hdl(vHdlIdx,:);
vHdlIdx = Hdl(:,3) < 4;
Hdl = Hdl(vHdlIdx,:);
data0 = Hdl';
%% Range limit
if size(RadiusRange,2) == 2
    RadiusL = RadiusRange(1);
    if RadiusL >= 4.5
        Len = size(data0,2);
        TmpData = [];
        for i = 1 : 1 : Len
            tmpPt = data0(1:3, i);
            if norm(tmpPt) > RadiusL
                TmpData = [TmpData,data0(:, i)];
            end
        end
        data0 = TmpData;
    end
end
%%
ptData = pointCloud(data0(1:3, :)');
DataTmp = data0;
RadiusU = RadiusRange(end);
if RadiusU < 200
    [HdlId, ~] = findNeighborsInRadius(ptData,[0,0,0], RadiusU);
    ptOrg = select( ptData ,HdlId );
    DataTmp = data0(:,HdlId);
else
    ptOrg = ptData;
end
%% downsample
HdlData = DataTmp;
if isRandom == 1
    if GridRes > 1  % GridRes is the number of points, actually 0503
        TruthRes = GridRes / ptOrg.Count;
        [ptHdl,vIdx] = pcDownSample(ptOrg, 'random', TruthRes);
        HdlData = DataTmp(:,vIdx);
    elseif GridRes == 1
        ptHdl = ptOrg;
    else
        % Hdl = pcdownsample(ptCloudIn, 'random', GridRes);
        [ptHdl,vIdx] = pcDownSample(ptOrg, 'random', GridRes);
        HdlData = DataTmp(:,vIdx);
    end
else
    if GridRes == 0
        ptHdl = ptOrg;
    else
        [ptHdl,vIdx] = pcDownSample(ptOrg, 'gridAverage', GridRes);
        HdlData = DataTmp(:,vIdx);
    end
end

end
