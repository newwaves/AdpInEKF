function CorresTF = CalTFUsingREG(kdMap, ptMap, ptOrg, XbkTF, ParaS)
%
% vMethods = {'p2pICP', 'p2plICP', 'NDT',  'SpsICP', 'HMRF', 'IRLS', 'MiNoM'};
% ParaS.RegM = vMethods{Sel};
% 
% Max Iteration 10 : p2plICP and Ndt
% Max Iteration 20 : p2pICP, MiNoM, SpsICP, IRLS, and HMRF

MaxIter = 10;
InitTransform = affine3d(XbkTF');
ptICP = pcdownsample(ptOrg, 'random', 0.03); % about 3000 points

if strcmp(ParaS.RegM, 'p2plICP')
    tform = p2plICP(ptICP, ptMap, kdMap, MaxIter, InitTransform); 
end
if strcmp(ParaS.RegM, 'p2pICP')  % MaxIter+10
    MaxIter = 20;
    tform = pcregistericp(ptICP, ptMap, 'Metric','pointToPoint','MaxIterations',MaxIter, 'InlierRatio', 0.8, 'InitialTransform',InitTransform);
end
if strcmp(ParaS.RegM, 'NDT')
    GridRes = 2;         
    tform = Ndt2020(ptICP, ptMap, GridRes, 'InitialTransform', InitTransform, 'OutlierRatio',0.8, 'MaxIterations', MaxIter);
end

if strcmp(ParaS.RegM, 'MiNoM')   % MaxIter+10
    cloud_ref = ptMap;
    cloud_mov = ptICP;
    params = genParamsFunMiNoM(cloud_mov.Location', ...  % 3XN matrix.
        cloud_ref.Location', ...                   % 3XN matrix.
        'ref_normal', cloud_ref.Normal', ...        % 3XN matrix.
        'P', [1.0 2.0], ...        % [2.0 2.0] can also be tried, but [1.0 2.0] seems to be more robust.
        'mode', 'point2plane', ... % 'point2plane' is robust than 'point2point'
        'Tf0', InitTransform.T', ...
        'maxIter_icp', 50,...    % MaxIter+10
        'is_show', 0, ... % is_show = 0 when use MiNoM in other applications.
        'verbose', 0 );   % verbose = 0 when use MiNoM in other applications.
    [dR, dT] = MiNoMFun(params);
    tform = affine3d([dR, dT; 0 0 0 1]');
end
if strcmp(ParaS.RegM, 'SpsICP') % MaxIter+10
    Mov0 = ptICP.Location';
    Ref0 = ptMap.Location';
    Tf0 = InitTransform.T';
    p = 1;
    [dR, dT] = SparseICP(Mov0, Ref0, kdMap, Tf0, p, MaxIter+10 );
    tform = affine3d([dR, dT; 0 0 0 1]');
end

if strcmp(ParaS.RegM, 'IRLS') % MaxIter+10
    Mov0 = ptICP.Location';
    Ref0 = ptMap.Location';
    Tf0 = InitTransform.T';
    p = 1;
    [dR, dT, ~] = IRLSICP(Mov0, Ref0, kdMap, Tf0, p, MaxIter+10 );
    tform = affine3d([dR, dT; 0 0 0 1]');
end
if strcmp(ParaS.RegM, 'HMRF') % 2019 ICRA
    Mov0 = double(ptICP.Location);
    Ref0 = double(ptMap.Location);
    Tf0 = InitTransform.T';
    params = getHMRFParas();
    params.icp_iter_max = 100;  % 20  MaxIter+10
    [tmpTF, ~] = HMRF_ICP(Ref0, Mov0, Tf0, params);
    tform = affine3d(tmpTF');
end
CorresTF = tform.T';

end