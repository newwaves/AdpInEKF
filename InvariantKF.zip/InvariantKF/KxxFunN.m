
function Kxx = KxxFunN(x1, x2, DeltaF)

SigmaN = 0.0003;
SigmaF = 0.01;
l = 2;
Kxx = SigmaF .^ 2 * exp(-(x1-x2).^2 / (2 * l * l)) + SigmaN .^ 2 * DeltaF;
end