function cIdx = PolarGridFun(SubPts, ResR, ResA, isshow)
if nargin < 4
    isshow = 1;
end
if nargin < 2
    ResR = 30.0;
    ResA = 45;  % 5 degree
    isshow = 1;
end
if size(SubPts,1) < 3
    disp('Error.');
end
% D = atan2d(Y,X)   attention !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
vPolar = [vecnorm(SubPts, 2, 2), atan2d(SubPts(:,2), SubPts(:,1))]; % D = atan2d(Y,X)
%
if isshow == 1
    figure;hold on;grid on;plot(vPolar(:,2), vPolar(:,1), 'k.');
end
%
invR = 1 ./ ResR;
invA = 1 ./ ResA;
xmin = min(vPolar(:,1)); xmax = max(vPolar(:,1));
ymin = min(vPolar(:,2)); ymax = max(vPolar(:,2));
dx = floor((xmax - xmin) * invR + 1);
dy = floor((ymax - ymin) * invA + 1);
dxy = dx*dy;  
if (dx == 0 || dy == 0 || dxy == 0)
    printf('vision:pointcloud:voxelSizeTooSmall');
end
if (dx ~= dxy / dy )
    printf('vision:pointcloud:voxelSizeTooSmall');
end
Len = size(vPolar, 1);
vvNewPts = vPolar(:,1:2); % 2D
vvRawIdx = [];
for n = 1 : 1 : Len
    tmpPt = vPolar(n,:);
    tmpdx = floor((tmpPt(1) - xmin) * invR + 1);
    tmpdy = floor((tmpPt(2) - ymin) * invA + 1);
    vvNewPts(n, :) = tmpdx + tmpdy * dx;
    vvRawIdx = [vvRawIdx; n];
end
[~,~,ic] = unique(vvNewPts,'rows','stable');
Low = min(ic);
Upw = max(ic);
%%
% vAllPts = [];
minVoxelPoints = 20;
if isshow == 1
    figure;hold on;grid on;
end
NumC = Upw - Low; vC = hsv(NumC + 1); Cnt = 0;
cIdx = {};
for n = Low : 1 : Upw
    Cnt = Cnt + 1;
    validIdx = ic == n;
    if sum(validIdx) <= minVoxelPoints
        continue;
    end
    vSelIdxs = vvRawIdx(validIdx);
    cIdx{end+1} = vSelIdxs;
%     vSelvPts = SubPts(vSelIdxs, :);
%     vAllPts = [vAllPts; [vSelvPts, n .* ones(size(vSelvPts,1), 1)]];
%     if isshow == 1
%         plot3(vSelvPts(:,1),vSelvPts(:,2),vSelvPts(:,3), '.', 'color', vC(Cnt,:));
%     end
end
% if isshow == 1
%     pcshow(vSelvPts);view(2);
% end

end