function [Score, vNewR, cNewVQ] = GeneTrainDataMultSector(kdMap, ptMap, ptOrg, ParaS)
% for Aom variance matrix deterimining  2021-02-02

% % trTF = ParaS.CorresTF * ParaS.CalibTF;  % 2020-12-04 version 1
trTF = ParaS.CorresTF;
[vTraPts, vHdlPts, vMapPts, vMapNor] = FindCorrespondences(kdMap, ptMap, ptOrg, trTF, 1, ParaS.TrainThr);
% added 2020-12-22
if size(vTraPts, 1) < 50
    Score = [0, 0];
    vNewR = [];
    for Radius = ParaS.MinR : ParaS.dR : ParaS.MaxR
        vNewR = [vNewR; Radius];
    end
    cNewVQ = {1000 .* ones(size(vNewR))};
    return;
end
%%
vDPts = vTraPts - vMapPts;

tmpNN = sqrt(vMapNor(:,1).^2 + vMapNor(:,2).^2 + vMapNor(:,3).^2);
tmpIxd = tmpNN > 10e-6;
tmpNN = tmpNN(tmpIxd);
OrgP2PL = sum(vDPts(tmpIxd,:) .* vMapNor(tmpIxd,:), 2) ./ tmpNN;
tmpP2PL = abs(OrgP2PL);

vHdlR = sqrt(vHdlPts(tmpIxd,1).^2 + vHdlPts(tmpIxd,2).^2 + vHdlPts(tmpIxd,3).^2);
tmpP2P = sqrt(vDPts(tmpIxd,1).^2 + vDPts(tmpIxd,2).^2 + vDPts(tmpIxd,3).^2);

vDist = [tmpP2P, tmpP2PL];
%--------------------------------------------------------------------------
% vCov = var(vDPts);  % Original Version
vttmp = var(tmpP2PL);       % 2020-09-20
vCov = [vttmp, vttmp, vttmp]; % 2020-09-20
Score = [ sum(vDist(:,1) < 0.5)/ ptOrg.Count, sum(vDist(:,2) < 0.5)/ ptOrg.Count];
% 2021-02-02
ResR = ParaS.MaxR;
ResA = ParaS.dAng; % 45 degree
cIdx = PolarGridFun(vHdlPts, ResR, ResA, 0);
minPoints = 20;
cNewVQ = {};
for n = 1 : 1 : length(cIdx)
    vtmpIdx = cIdx{n};
    if sum(vtmpIdx) <= minPoints
        continue;
    end
    [vNewR, tmpVQ] = StatisQ(vHdlR(vtmpIdx,:), tmpP2PL(vtmpIdx,:), ParaS);
    cNewVQ{end+1} = tmpVQ;
end
end
%%
function [vNewR, vNewV] = StatisQ(vHdlR, vP2PL, ParaS)
vNewR = [];
vNewV = [];
vVarP2PL = [];
for Radius = ParaS.MinR : ParaS.dR : ParaS.MaxR
    vIDx = (vHdlR >= (Radius - ParaS.dR/2)) & (vHdlR <= (Radius + ParaS.dR/2));
    tmpSurDist = vP2PL(vIDx, :); %OrgP2PL(vIDx, :);  % tmpP2PL(vIDx, :) 2020-09-27
    vPtsLen = size(tmpSurDist,1);
    if vPtsLen < 5
        if Radius ==  ParaS.MinR  % the first element
            vVarP2PL = [vVarP2PL; 1e-3];
        else
            vVarP2PL = [vVarP2PL; vVarP2PL(end,:)];
        end
    else
        vVarP2PL = [vVarP2PL; var(tmpSurDist)];
    end
    vNewR = [vNewR; Radius];
end
vNewV = vVarP2PL;%[vVarP2PL, vVarP2PL, vVarP2PL];

end