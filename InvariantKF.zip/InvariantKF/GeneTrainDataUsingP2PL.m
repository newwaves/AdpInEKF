function [Score, vNewR, vCov, vNewVQ1, vNewVQ2, vNewVQ3, vNewVQ4] = GeneTrainDataUsingP2PL(kdMap, ptMap, ptOrg, ParaS)
%UNTITLED2 此处显示有关此函数的摘要  2020-11-03
%   for Aom variance matrix deterimining

% % trTF = ParaS.CorresTF * ParaS.CalibTF;  % 2020-12-04 version 1
trTF = ParaS.CorresTF;
[vTraPts, vHdlPts, vMapPts, vMapNor] = FindCorrespondences(kdMap, ptMap, ptOrg, trTF, 1, ParaS.TrainThr);
% added 2020-12-22
if size(vTraPts, 1) < 50
    Score = [0, 0];
    vNewR = [];
    for Radius = ParaS.MinR : ParaS.dR : ParaS.MaxR
        vNewR = [vNewR; Radius];
    end
    vCov = [0 0 0];
    vNewVQ1 = ParaS.TrainThr * ones(size(vNewR,1),1);
    vNewVQ2 = ParaS.TrainThr * ones(size(vNewR,1),1);
    vNewVQ3 = ParaS.TrainThr * ones(size(vNewR,1),1);
    vNewVQ4 = ParaS.TrainThr * ones(size(vNewR,1),1);
    return;
end
%%
validLen = size(vHdlPts,1);
vDPts = zeros(validLen,3); % [x y z]
vDist = zeros(validLen,2); % [pointTopoint, pointToplane]
vHdlR = zeros(validLen,1);
% for i = 1 : 1 : validLen
%     vHdlR(i,:) = norm(vHdlPts(i,:));
%     vDPts(i,:) = vTraPts(i,:) - vMapPts(i,:);
%     PtoP = norm(vDPts(i,:));
%     PtoPL = abs(vDPts(i,:) * vMapNor(i,:)' / norm(vMapNor(i,:)));
%     vDist(i,:) = [PtoP,PtoPL];
% end
% modified @ 2020-04-06
vDPts = vTraPts - vMapPts;

tmpNN = sqrt(vMapNor(:,1).^2 + vMapNor(:,2).^2 + vMapNor(:,3).^2);
tmpIxd = tmpNN > 10e-6;
tmpNN = tmpNN(tmpIxd);
OrgP2PL = sum(vDPts(tmpIxd,:) .* vMapNor(tmpIxd,:), 2) ./ tmpNN;
tmpP2PL = abs(OrgP2PL);

vHdlR = sqrt(vHdlPts(tmpIxd,1).^2 + vHdlPts(tmpIxd,2).^2 + vHdlPts(tmpIxd,3).^2);
tmpP2P = sqrt(vDPts(tmpIxd,1).^2 + vDPts(tmpIxd,2).^2 + vDPts(tmpIxd,3).^2);

vDist = [tmpP2P, tmpP2PL];
%--------------------------------------------------------------------------
% vCov = var(vDPts);  % Original Version
vttmp = var(tmpP2PL);       % 2020-09-20
vCov = [vttmp,vttmp,vttmp]; % 2020-09-20
Score = [ sum(vDist(:,1) < 0.5)/ ptOrg.Count, sum(vDist(:,2) < 0.5)/ ptOrg.Count];
%
IdxQ1 = (vHdlPts(tmpIxd,1) >= 0) & (vHdlPts(tmpIxd,2) >= 0);
IdxQ2 = (vHdlPts(tmpIxd,1) <= 0) & (vHdlPts(tmpIxd,2) >= 0);
IdxQ3 = (vHdlPts(tmpIxd,1) <= 0) & (vHdlPts(tmpIxd,2) <= 0);
IdxQ4 = (vHdlPts(tmpIxd,1) >= 0) & (vHdlPts(tmpIxd,2) <= 0);
% vNewR, vNewVQ1, vNewVQ2, vNewVQ3, vNewVQ4
[vNewR, vNewVQ1] = StatisQ(vHdlR(IdxQ1,:), tmpP2PL(IdxQ1,:), ParaS);
[~, vNewVQ2] = StatisQ(vHdlR(IdxQ2,:), tmpP2PL(IdxQ2,:), ParaS);
[~, vNewVQ3] = StatisQ(vHdlR(IdxQ3,:), tmpP2PL(IdxQ3,:), ParaS);
[~, vNewVQ4] = StatisQ(vHdlR(IdxQ4,:), tmpP2PL(IdxQ4,:), ParaS);
end
%%
function [vNewR, vNewV] = StatisQ(vHdlR, vP2PL, ParaS)
vNewR = [];
vNewV = [];
vVarP2PL = [];
for Radius = ParaS.MinR : ParaS.dR : ParaS.MaxR
    vIDx = (vHdlR >= (Radius - ParaS.dR/2)) & (vHdlR <= (Radius + ParaS.dR/2));
    tmpSurDist = vP2PL(vIDx, :); %OrgP2PL(vIDx, :);  % tmpP2PL(vIDx, :) 2020-09-27
    vPtsLen = size(tmpSurDist,1);
    if vPtsLen < 5
        if Radius ==  ParaS.MinR  % the first element
            vVarP2PL = [vVarP2PL; 1e-3];
        else
            vVarP2PL = [vVarP2PL; vVarP2PL(end,:)];
        end
    else
        vVarP2PL = [vVarP2PL; var(tmpSurDist)];
    end
    vNewR = [vNewR; Radius];
end
vNewV = vVarP2PL;%[vVarP2PL, vVarP2PL, vVarP2PL];

end