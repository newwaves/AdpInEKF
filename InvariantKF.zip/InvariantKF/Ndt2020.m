function [tform, movingReg, rmse] = Ndt2020(moving, fixed, gridStep, varargin)
% Copyright 2017-2019 The MathWorks, Inc.
%
% References
% ----------
% [1] P. Biber, W. Strasser, "The normal distributions transform: A
%     new approach to laser scan matching," in Proceedings of IEEE/RSJ
%     International Conference on Intelligent Robots and Systems
%     (IROS), 2003, pp. 2743-2748
%
% [2] Magnusson, M. (2013). The Three-Dimensional Normal-Distributions
%     Transform - an Efficient Representation for Registration, Surface
%     Analysis, and Loop Detection. PhD thesis, Orebro University.

%#codegen

% Parse the inputs


[isValid, ptCloudA, ptCloudB, maxStepSize, outlierRatio, maxIterations, tolerance, ...
    initTform, verbose] = parseInputs(  moving, fixed, gridStep, varargin{:});

if isValid == 1
    tform = affine3d(initTform);
    return;
end


gridStep = double(gridStep);
% Convert to Euler angle format
x0 = vision.internal.eul.tform2pose(initTform);

% Voxelize the reference point cloud
minVoxelPoints = 6;         % Remove voxels that contain less than 6 points
eigenValueRatio = 100;      % Flat the covariance to avoid singularity
[mvals, iCov] = vision.internal.pc.voxelGridFilter(ptCloudB.Location, gridStep, minVoxelPoints, eigenValueRatio);

coder.internal.errorIf(isempty(mvals),'vision:pointcloud:notEnoughValidVoxels');

% Create kdtree for fast indexing
[kdtree, pLocationHandle] = constructKdtree(mvals);

% Initialize gaussian fitting parameters for estimation of likelihood of
% each point w.r.t to a distribution of a voxel that encloses the point. Eq
% 6.8, Martin 2013.
c1 = max(10*(1 - outlierRatio), eps);      % Gaussian-Distribution parameter c1
c2 = max(outlierRatio/gridStep^3, eps);    % Uniform distribution parameter c2
d3 = -log(c2);
d1 = -log(c1 + c2) - d3;
d2 = -2*log((-log(c1*exp(-0.5) + c2) - d3) / d1);

% Set up the NLP solver
args.ps = ptCloudA.Location;
args.mvals = mvals;
args.iCov = iCov;
args.tree = kdtree;
args.d1 = d1;
args.d2 = d2;
args.radius = gridStep;
args.SolutionEvaluationFcn = @solutionEvaluationNDT;

solver = vision.internal.ndt.NLPSolverLineSearch(...
    @visionNDTComputeScoreDerivatives, @solutionEvaluationNDT,...
    @checkGradientInitializationNDT,args);

params = getSolverParams(solver);
params.MaxIterations = maxIterations;
params.MaxStepSize = maxStepSize;
params.ExtraSolutionEvalArgs = double(tolerance);

if isSimMode && verbose
    % Setup the message printer
    params.PrintFcn = @printMessage;
    params.Verbose = verbose;
end

setSolverParams(solver, params);

% Search the best pose with line search algorithm
x = solver.solve(x0(:));

% Convert to rigid3d format
tform = vision.internal.eul.pose2tform(x.', class(moving.Location));

if nargout >= 2
    movingReg = pctransform(moving, tform);
end

if nargout >= 3
    % rmse is based on point-to-point correspondence
    ptCloudA = pctransform(ptCloudA, tform);    % ptCloudA is the moving point cloud
    [~, dists] = multiQueryKNNSearchImpl(ptCloudB, ptCloudA.Location, 1);
    rmse = sqrt(sum(dists(:))/numel(dists));
    rmse = cast(rmse,'like',moving.Location);
end

deleteKdtree(kdtree, pLocationHandle,  class(mvals));
end

%--------------------------------------------------------------------------
function [isValid, ptCloudA, ptCloudB, maxStepSize, outlierRatio, maxIterations, tolerance, ...
    initTform, verbose] = parseInputs( moving, fixed, gridStep, varargin)

coder.internal.prefer_const( varargin{:} );

validateattributes(moving, {'pointCloud'}, {'scalar'}, mfilename, 'moving');
validateattributes(fixed, {'pointCloud'}, {'scalar'}, mfilename, 'fixed');
validateattributes(gridStep, {'single', 'double'}, ...
    {'real','scalar', 'nonnan', 'nonsparse','positive'});

% A copy of the input with unorganized M-by-3 data
if isa(moving.Location, 'double')
    ptCloudA = removeInvalidPoints(moving);
else
    movingUnorg = removeInvalidPoints(moving);
    ptCloudA = pointCloud( double(movingUnorg.Location) );
end

if isa(fixed.Location, 'double')
    ptCloudB = removeInvalidPoints(fixed);
else
    fixedUnorg = removeInvalidPoints(fixed);
    ptCloudB = pointCloud(double(fixedUnorg.Location));
end

if(ptCloudA.Count < 50 || ptCloudB.Count < 50)
    t = [0 0 0];
else
% Initial translation
t = mean(ptCloudB.Location) - mean(ptCloudA.Location);
end

% Set input parser
defaults = struct(...
    'StepSize',         0.1, ...
    'OutlierRatio',     0.55,...
    'MaxIterations',    30,...
    'Tolerance',        [0.01, 0.5], ...
    'InitialTransform', rigid3d(eye(3), t),...
    'Verbose',          false);

if isSimMode
    parser = inputParser;
    parser.CaseSensitive = false;
    
    parser.addParameter('StepSize', defaults.StepSize);
    parser.addParameter('OutlierRatio', defaults.OutlierRatio);
    parser.addParameter('MaxIterations', defaults.MaxIterations);
    parser.addParameter('Tolerance', defaults.Tolerance);
    parser.addParameter('InitialTransform', defaults.InitialTransform);
    parser.addParameter('Verbose', defaults.Verbose);
    
    parser.parse(varargin{:});
    
    maxStepSize      = parser.Results.StepSize;
    outlierRatio     = parser.Results.OutlierRatio;
    maxIterations    = parser.Results.MaxIterations;
    tolerance        = parser.Results.Tolerance;
    
    initialTransform = parser.Results.InitialTransform;
    
    verbose = parser.Results.Verbose;
else
    
    % Define parser mapping struct
    pvPairs = struct( ...
        'StepSize',         uint32(0), ...
        'OutlierRatio',     uint32(0), ...
        'MaxIterations',    uint32(0), ...
        'Tolerance',        uint32(0), ...
        'InitialTransform', uint32(0),...
        'Verbose',          uint32(0));
    
    % Specify parser options
    poptions = struct( ...
        'CaseSensitivity', false, ...
        'StructExpand',    true, ...
        'PartialMatching', true);
    
    % Parse PV pairs
    pstruct = coder.internal.parseParameterInputs(pvPairs, ...
        poptions, varargin{:});
    % Extract inputs
    maxStepSize       = coder.internal.getParameterValue(pstruct.StepSize, defaults.StepSize, varargin{:});
    outlierRatio      = coder.internal.getParameterValue(pstruct.OutlierRatio, defaults.OutlierRatio, varargin{:});
    maxIterations     = coder.internal.getParameterValue(pstruct.MaxIterations, defaults.MaxIterations, varargin{:});
    tolerance         = coder.internal.getParameterValue(pstruct.Tolerance, defaults.Tolerance, varargin{:});
    initialTransform  = coder.internal.getParameterValue(pstruct.InitialTransform, defaults.InitialTransform, varargin{:});
    verbose           = coder.internal.getParameterValue(pstruct.Verbose, defaults.Verbose, varargin{:});
end

funcName = mfilename;
validateattributes(maxStepSize, {'single', 'double'}, {'real','scalar','positive'},...
    funcName, 'StepSize');
validateattributes(outlierRatio,{'single', 'double'}, {'real','nonempty','scalar','>=',0,'<',1},...
    funcName, 'OutlierRatio');
validateattributes(maxIterations,{'single', 'double'}, {'scalar','integer','positive'},...
    funcName, 'MaxIterations');
validateattributes(tolerance,{'single', 'double'}, {'real','nonnegative','finite','numel', 2},...
    funcName, 'Tolerance');
validateattributes(initialTransform,{'affine3d','rigid3d'}, {'scalar'},funcName, 'InitialTransform');
validateattributes(verbose,{'logical'}, {'scalar','nonempty'}, funcName, 'Verbose');

if isa(initialTransform, 'affine3d')
  % Convert to rigid3d and extract transformation matrix
  initRigidTform = rigid3d(initialTransform.T);
  initTform = double(initRigidTform.T);
else
  initTform = double(initialTransform.T);
end

outlierRatio  = double(outlierRatio);
tolerance     = [double(tolerance(1)), double(tolerance(2))*pi/180];
maxIterations = double(maxIterations);

isValid = 0;
if(ptCloudA.Count < 50 || ptCloudB.Count < 50)
    isValid = 1;
    return;
end
% At least three points are needed to determine a 3-D transformation
coder.internal.errorIf((ptCloudA.Count < 3 || ptCloudB.Count < 3), ...
    'vision:pointcloud:notEnoughPoints');

end

%--------------------------------------------------------------------------
function tf = solutionEvaluationNDT(x, xTrial, tolerance)
% Stop the NLP solver if pose change is below tolerance.

% Difference in translation
tdiff = x(1:3)-xTrial(1:3);

% Difference in rotation (radian)
rdiff = x(4:6)-xTrial(4:6);

tf = (tdiff'*tdiff < tolerance(1)^2) & (rdiff'*rdiff < tolerance(2)^2);
end

%--------------------------------------------------------------------------
function checkGradientInitializationNDT(~, gradient, ~)
% Check that gradient is valid at initialization

% coder.internal.errorIf(all(gradient==0),'vision:pointcloud:ndtNoGradientAtInitialization');
end

%--------------------------------------------------------------------------
function printMessage(msg, arg)
% Verbose message printer for NLP solver

persistent printer;
if isempty(printer)
    printer = vision.internal.MessagePrinter.configure(true);
end

if msg == vision.internal.ndt.NLPSolverPrintFlags.IterationStart
    printer.linebreak;
    printer.print('--------------------------------------------\n');
    printer.printMessage('vision:pointcloud:ndtIteration',arg);
    
elseif msg == vision.internal.ndt.NLPSolverPrintFlags.CurrentFcn
    printer.printMessage('vision:pointcloud:ndtCurrentFcn',num2str(arg));
    
elseif msg == vision.internal.ndt.NLPSolverPrintFlags.CurrentVar
    printer.printMessage('vision:pointcloud:ndtCurrentVarTranslation',...
        num2str(arg.x(1)), num2str(arg.x(2)), num2str(arg.x(3)));
    printer.printMessage('vision:pointcloud:ndtCurrentVarRotation', ...
        num2str(rad2deg(arg.x(4))), num2str(rad2deg(arg.x(5))), num2str(rad2deg(arg.x(6))));
    
elseif msg == vision.internal.ndt.NLPSolverPrintFlags.IterationExit
    printer.linebreak;
    printer.print('--------------------------------------------\n');
    switch arg
        case vision.internal.ndt.NLPSolverExitFlags.ChangeInErrorBelowMinimum
            printer.printMessage('vision:pointcloud:nlpStopCondSmallAbsFunVal');
        case vision.internal.ndt.NLPSolverExitFlags.LocalMinimumFound
            printer.printMessage('vision:pointcloud:nlpStopCondSmallGrad');
        case vision.internal.ndt.NLPSolverExitFlags.StepSizeBelowMinimum
            printer.printMessage('vision:pointcloud:nlpStopCondSmallChangeOfX');
        case vision.internal.ndt.NLPSolverExitFlags.SolutionCheckFailed
            printer.printMessage('vision:pointcloud:ndtStopCondSolutionCheck');
        case vision.internal.ndt.NLPSolverExitFlags.MaximumIterationReached
            printer.printMessage('vision:pointcloud:nlpStopCondMaxIteration');
    end
end
end

%--------------------------------------------------------------------------
function flag = isSimMode()

flag = isempty(coder.target);
end

%--------------------------------------------------------------------------
function [kdtree, pLocationHandle] = constructKdtree(mvals)
% Create kdtree for fast indexing

options = struct('numTrees', 1, 'bucketSize', 1, 'seed', 0);
if isSimMode
    kdtree = vision.internal.Kdtree();
    kdtree.index(mvals, options);
    pLocationHandle = [];
elseif pointclouds.internal.codegen.isTargetMATLABHost
    kdtree = vision.internal.buildable.kdtreeBuildable.kdtreeConstruct(class(mvals));
    if ismatrix(mvals)
        numPts = size(mvals,1);
        numDims = size(mvals,2);
    else
        numPts = size(mvals,1) * size(mvals,2);
        numDims = size(mvals,3);
    end
    pLocationHandle = vision.internal.buildable.kdtreeBuildable.kdtreeGetLocationPointer(mvals, class(mvals));
    vision.internal.buildable.kdtreeBuildable.kdtreeIndex(kdtree, class(mvals), pLocationHandle, numPts, numDims, options);
else
    kdtree = vision.internal.codegen.Kdtree(class(mvals));
    if ~isempty(kdtree) && ~kdtree.IsIndexed
        kdtree.index(mvals);
    end
     pLocationHandle = [];
end

end



function deleteKdtree(kdtree, pLocationHandle, pointCloudDataType)
if ~isSimMode && pointclouds.internal.codegen.isTargetMATLABHost
    
    vision.internal.buildable.kdtreeBuildable.kdtreeDeleteLocationPointer(pLocationHandle,...
        pointCloudDataType);
    
    vision.internal.buildable.kdtreeBuildable.kdtreeDelete(kdtree, pointCloudDataType);
    
end
end