function params = getParamFun()
params.isShow = 0;
params.isMatMap = 1;
params.SeqIdx = 0;  % KitSeq00 KitSeq06 Campus Sudoku
%
DataSet = 'KitSeq00';  %{'KitSeq00', 'KitSeq06', 'Campus', 'Sudoku'};
if strcmp(DataSet, 'KitSeq00') || strcmp(DataSet, 'KitSeq06')
    params.CalTF = eye(4);
    P = load('KitSensorNoise.mat');
    params.StartID = 1;
    params.dFrm = 5;
    
    A = load(sprintf('KITTI%02d/GrdTruth.mat',params.SeqIdx));  %
    B = load(sprintf('KITTI%02d/OdoPose.mat',params.SeqIdx));  %
    params.vGrdTF = A.vTestTFNew;
    params.GrdPose = A.vTestPoseNew;
    params.PoseHDL = A.vTestTF;
    params.SelRange = A.vIdxTest;
    params.OdometryInfo = CvTF2vEul(B.vNewTF); % the input signal is already noise
    params.CovM = diag(B.OnLineV);              % 2020-05-03  OnLine
    params.GpsTf = [params.vGrdTF(:,:,params.StartID); 0 0 0 1];
elseif strcmp(DataSet, 'Campus')
    Ang = 1.0;
    R = [cosd(Ang) sind(Ang) 0; -sind(Ang) cosd(Ang) 0; 0 0 1];
    t = [1.1; 0.0; 0.0];
    params.CalTF = [R,t; 0 0 0 1]; % S3 before 2018-11-01 (XJTU)
    P = load('HdlS3DataStarFNoise.mat');
    params.StartID = 2800;
    params.dFrm = 3;
elseif strcmp(DataSet, 'Sudoku')
    CalibTF = [0.999350123742238,0.0299895011024552,-0.0199000000000000,1.2;-0.0305832320226641,0.999132216435366,-0.0293000000000000,0;0.0190121775156717,0.0298837264428750,0.999400000000000,1;0,0,0,1];
    params.CalTF = CalibTF;
    P = load('HdlS2DataSudokuLocMatchNoise.mat');% 2021-01-12  DenseFinal2112 successful in Cpp
    params.StartID = 1;
    params.dFrm = 1;
end
% figure;plot(P.vNewR, P.vNewV(:,1),'r.-');hold on;grid on;plot(P.vNewR, P.vNewV(:,2),'g.-');plot(P.vNewR, P.vNewV(:,3),'b.-');
params.InvCalTF = inv(params.CalTF);

%
params.modelC = 10;
%
params.isFirst = 1;
params.CorrectThr = 5;     %
params.TrainThr = 100;     % 
params.N = 3;        % N=1 N=2 N=3
params.dR = 2;       % new version dR = 2;2020-04-04
params.MinR = 5;     % DemoAdaptiveKit06_2000 2020-04-28
params.MaxR = 30;
params.dAng = 90; % 45 degree
vNewR = params.MinR : params.dR : params.MaxR;
vRads = []; % 0.1m
for Radius = params.MinR : 0.1 : params.MaxR + 0.1
    vRads = [vRads;Radius];
end
params.vRads = vRads;

params.MeaNoise = [params.vRads, polyval(P.Px,params.vRads), polyval(P.Py,params.vRads), polyval(P.Pz,params.vRads)];
params.StdNoise = mean(params.MeaNoise(:,2:4)); % 2020-11-16
% 2021-01-16 added code
params.MeaNoise(params.MeaNoise(:,2) < 1e-3, 2) = 1e-3;
params.MeaNoise(params.MeaNoise(:,3) < 1e-3, 3) = 1e-3;
params.MeaNoise(params.MeaNoise(:,4) < 1e-3, 4) = 1e-3;
deltaR = 2;
params.QuevR = params.vRads(1:2:end);
params.Mod = createns( params.QuevR);
params.MeaNoise = params.MeaNoise(1:deltaR:end, :);
% figure;hold on;grid on;
% plot(params.MeaNoise(:,1),params.MeaNoise(:,2),'r.-');
% plot(params.MeaNoise(:,1),params.MeaNoise(:,3),'g.-');
% plot(params.MeaNoise(:,1),params.MeaNoise(:,4),'b.-');
%
params.K = TrainGPN(vNewR);   % new version dR = 2;2020-04-04
params.invK = inv(params.K);
params.Cov = [1, 0.1,0.1,0.1];
params.RadiusRange = [params.MinR, params.MaxR]; % Limit the range of lidar

params.isGridDown = 0;  % random downsample

params.RegM = 'ICP'; % NDT  SpsICP HMRF IRLS MiNoM


end