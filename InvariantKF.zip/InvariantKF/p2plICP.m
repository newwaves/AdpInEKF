function [tform, movingReg, rmse] = p2plICP(ptCloudA, ptCloudB, KDMap, maxIterations, initialTransform, inlierRatio, TrimDist )
    if nargin < 5
        initialTransform = affine3d();
        inlierRatio = 0.8;
        TrimDist = 2;
    end
    if nargin < 6
        inlierRatio = 0.8;
        TrimDist = 2;
    end

% 	inlierRatio = 1.0;  % improve robust 2017-09-08

    tolerance = [0.0001, 0.00009];
    %%
    Rs = zeros(3, 3, maxIterations+1);
    Ts = zeros(3, maxIterations+1);
    % Quaternion and translation vector
    qs = [ones(1, maxIterations+1); zeros(6, maxIterations+1)];
    % RMSE
    Err = zeros(maxIterations+1, 1); 
    % Apply the initial condition.
    % We use pre-multiplication format in this algorithm.
    Rs(:,:,1) = initialTransform.T(1:3, 1:3)';
    Ts(:,1) = initialTransform.T(4, 1:3)';
    qs(:,1) = [rotm2quat(Rs(:,:,1))'; Ts(:,1)];
    locA = ptCloudA.Location;
    if qs(1) ~= 0 || any(qs(2:end,1))
        locA = rigidTransform(ptCloudA.Location, Rs(:,:,1), Ts(:,1));
    end
    stopIteration = maxIterations;

    upperBound = max(1, round(inlierRatio(1)*ptCloudA.Count));   
    isICPSuccess = 1;
    % Start ICP iterations
    for i = 1 : maxIterations
        % Find the correspondence
        [indices, dists] = knnsearch(KDMap, locA, 'dist','euclidean');
        % Remove outliers      
        keepInlierA = false(ptCloudA.Count, 1); 
        [~, idx] = sort(dists);
        upperBound = length(find(dists < TrimDist));
        keepInlierA(idx(1:upperBound)) = true;       
        inlierIndicesA = find(keepInlierA);
        inlierIndicesB = indices(keepInlierA);
        inlierDist = dists(keepInlierA);

        if numel(inlierIndicesA) < 3
            TrimDist = TrimDist + 5;
            if TrimDist > 10
                isICPSuccess = 0;
                break;
            end
            continue;
            % error(message('vision:pointcloud:notEnoughPoints'));
        end       
        
        if i == 1
            Err(i) = sqrt(sum(inlierDist)/length(inlierDist));
        end
   
        isPointToPoint = 0;% error when selected
        if isPointToPoint
            [R, T] = vision.internal.calibration.rigidTransform3D(locA(inlierIndicesA, :), ptCloudB.Location(inlierIndicesB, :));
        else % PointToPlane
            [R, T] = pointToPlaneMetric1008(locA(inlierIndicesA, :),ptCloudB.Location(inlierIndicesB, :), ptCloudB.Normal(inlierIndicesB, :));
        end   
        
        % Bad correspondence may lead to singular matrix
        if any(isnan(T))||any(isnan(R(:)))
            isICPSuccess = 0;
            break;
            error(message('vision:pointcloud:singularMatrix'));
        end
        
        % Update the total transformation
        Rs(:,:,i+1) = R * Rs(:,:,i);
        Ts(:,i+1) = R * Ts(:,i) + T;
        
        % RMSE
        locA = rigidTransform(ptCloudA.Location, Rs(:,:,i+1), Ts(:,i+1));
        squaredError = sum((locA(inlierIndicesA, :) - ptCloudB.Location(inlierIndicesB, :)).^2, 2);
        Err(i+1) = sqrt(sum(squaredError)/length(squaredError));
        % Convert to vector representation
        %qs(:,i+1) = [vision.internal.quaternion.rotationToQuaternion(Rs(:,:,i+1)); Ts(:,i+1)];
        qs(:,i+1) = [rotm2quat(Rs(:,:,i+1))'; Ts(:,i+1)];
        % Check convergence    
        % Compute the mean difference in R/T from the recent three iterations.
        [dR, dT] = getChangesInTransformation;
        % Stop ICP if it already converges
        if dT <= tolerance(1) && dR <= tolerance(2)
            stopIteration = i;
            break;
        end
    end
    
    if isICPSuccess == 1
        % Make the R to be orthogonal as much as possible
        R = Rs(:,:,stopIteration+1)';
        [U, ~, V] = svd(R);
        R = U * V';
        tformMatrix = [R, zeros(3,1);Ts(:, stopIteration+1)',  1];
        tform = affine3d(tformMatrix);
        rmse = Err(stopIteration+1);
        if nargout >= 2
            movingReg = pctransform(ptCloudA, tform);
        end
    else
        tform = initialTransform;
        rmse = 0;
        movingReg = ptCloudA;
    end
    %======================================================================
    % Nested function to compute the changes in rotation and translation
    %======================================================================
    function [dR, dT] = getChangesInTransformation
        dR = 0;
        dT = 0;
        count = 0;
        for k = max(i-2,1):i
            % Rotation difference in radians
            rdiff = acos(dot(qs(1:4,k),qs(1:4,k+1))/(norm(qs(1:4,k))*norm(qs(1:4,k+1))));
            % Euclidean difference
            tdiff = sqrt(sum((Ts(:,k)-Ts(:,k+1)).^2));
            dR = dR + rdiff;
            dT = dT + tdiff;
            count = count + 1;
        end
        dT = dT/count;
        dR = dR/count;
    end
end

%==========================================================================
% Determine if transformation is rigid transformation
%==========================================================================
function tf = isRigidTransform(tform)
    singularValues = svd(tform.T(1:tform.Dimensionality,1:tform.Dimensionality));
    tf = max(singularValues)-min(singularValues) < 100*eps(max(singularValues(:)));
    tf = tf && abs(det(tform.T)-1) < 100*eps(class(tform.T));
end 
%%
%==========================================================================
function B = rigidTransform(A, R, T)
    B = A * R';
    B(:,1) = B(:,1) + T(1);
    B(:,2) = B(:,2) + T(2);
    B(:,3) = B(:,3) + T(3);
end
%%
function [R, T] = pointToPlaneMetric1008(p, q, nv)
    % Set up the linear system
    cn = [cross(p,nv,2),nv];
    C = cn'*cn;
    qp = q-p;
    b =  [sum(sum(qp.*repmat(cn(:,1),1,3).*nv, 2));
          sum(sum(qp.*repmat(cn(:,2),1,3).*nv, 2));
          sum(sum(qp.*repmat(cn(:,3),1,3).*nv, 2));
          sum(sum(qp.*repmat(cn(:,4),1,3).*nv, 2));
          sum(sum(qp.*repmat(cn(:,5),1,3).*nv, 2));
          sum(sum(qp.*repmat(cn(:,6),1,3).*nv, 2))];
    % X is [alpha, beta, gamma, Tx, Ty, Tz]
    
    X = C\b;  % 可能 矩阵接近奇异值，或者缩放错误。
   
    cx = cos(X(1)); 
    cy = cos(X(2)); 
    cz = cos(X(3)); 
    sx = sin(X(1)); 
    sy = sin(X(2)); 
    sz = sin(X(3)); 

    R = [cy*cz, sx*sy*cz-cx*sz, cx*sy*cz+sx*sz;
         cy*sz, cx*cz+sx*sy*sz, cx*sy*sz-sx*cz;
           -sy,          sx*cy,          cx*cy];

    T = X(4:6);
end