function [Xk, Ck] = InEKF_Update(kdMap, ptMap, ptHdl, Cbk, XbkTF, ParaS)
coresTF = ParaS.CorresTF;
[~, vZk, vMapPts, ~] = FindCorrespondences(kdMap, ptMap, ptHdl, coresTF, 1, ParaS.CorrectThr);

if size(vMapPts, 1) > 20   % the prediction value of observed points
    % right - invariant
    vZbk = [vZk, ones(size(vZk, 1), 1)]; %  vZk, actually
    vtmpPts = XbkTF * vZbk';
    vZbk = vtmpPts(1:3, :)';
    
    if ParaS.isAdp == 1   % attention : D = atan2d(Y,X)
        vIdxAng = ceil( (atan2d(vZk(:,2), vZk(:,1)) + 180)./ ParaS.dAng ); % which cell can be found ?
        vIdxRad = knnsearch(ParaS.Mod, vecnorm(vZk, 2, 2), 'k', 1);% which radius can be selected ?
    else
        Qk = diag( ParaS.Cov );
    end

    eState = eye(4);
    for i = 1 : 1 : size(vZk,1)
        if ParaS.isAdp == 1
            Radius = norm(vZk(i,:)); % vRs(i)
            if Radius < ParaS.RadiusRange(1)
                continue;
            else
                tmpGPR = ParaS.MultCov{vIdxAng(i)};
                tmpVar = tmpGPR(vIdxRad(i), :);
                Qk = diag( tmpVar(2:4) );
            end
        end
        Hx = [skew(vMapPts(i,:)), -eye(3)]; % right2
        
        Sk = Hx * Cbk * Hx' + Qk;
        Kk = Cbk * Hx' / Sk;
        eState = Exp(Kk * (vZbk(i,:)' - vMapPts(i,:)')) * eState; % right2
        
        Cbk = (eye(6) - Kk * Hx) * Cbk;
        %%2021-04-09 Symmetric positive definite
        % Cbk = (eye(6) - Kk * Hx) * Cbk * (eye(6) - Kk * Hx)' + Kk * Qk * Kk';
    end
    %-----------------------------------------------------
    Xk = eState * XbkTF; % right-invariant
    Ck = Cbk;
    %-----------------------------------------------------
else
    Xk = XbkTF;
    Ck = Cbk;
end
end
%%
function state = Exp(epslion) % R, t
R = expm(skew(epslion(1:3)));
t = epslion(4:6);
state = [R, t; 0 0 0 1];
end