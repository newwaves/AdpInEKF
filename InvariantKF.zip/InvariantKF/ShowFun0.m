FixPts = 1.*[-80 -80 -10;-80 -80 10;-80 80 -10;-80 80 10;80 -80 -10;80 -80 10;80 80 -10;80 80 10;];

[vPtsP2P, vPtsP2L] = FindDiffvPts(kdMap, ptMap, ptOrg, Xk);
figure(HF); cla; hold on; grid on;FSize = 10; %  
%
subplot(4,4,[6,7,10,11]);set(gca,'color',[0.1 0.1 0.1]);cla; hold on; grid on;
pcshow(FixPts);
pcshow(ptOrg.Location, 'g');
plot3(vPtsP2P(:,1),vPtsP2P(:,2),vPtsP2P(:,3), 'ro', 'MarkerSize', 5);
plot3(vPtsP2L(:,1),vPtsP2L(:,2),vPtsP2L(:,3), 'ro', 'MarkerSize', 5);
% pos = tmpTf(1:3,end)';
% vIdx = rangesearch(kdMap, pos, ParaS.MaxR+80);
% subMap = pointCloud(ptMap.Location(vIdx{:},:));
invtmpTF = inv(Xk);
SubO = myRigidTransform(subMap.Location, invtmpTF(1:3,1:3), invtmpTF(1:3,end));
pcshow(SubO);
view(2);
Traj = squeeze(TTf(:, 4, 2:end));
SubT = invtmpTF * Traj;
ttt = [params.GrdPose(1:id,1:3)';ones(1, id)];
SubG = invtmpTF * ttt;
plot3(SubT(1, :), SubT(2, :), SubT(3, :), 'g>-', 'markersize', 8 );
plot3(SubG(1, :), SubG(2, :), SubG(3, :), 'rh-', 'markersize', 10 );
x = [0 0];
y = [-100 100];
line(x,y,'Color','blue','LineWidth',3,'LineStyle','--');
y = [0 0];
x = [-100 100];
line(x,y,'Color','blue','LineWidth',3,'LineStyle','--');
xlabel('x');ylabel('y');zlabel('z');
% vGprTe, vGprTr
MaxZ = max(max(max(vGprTe)), 0.01); %  vGpr : N X 5
subplot(4,4,1);set(gca,'color',[0.3 0.3 0.3]);cla; hold on; grid on;box on;
plot(vGprTr(:,1), vGprTr(:,3),'w+--','MarkerSize',10, 'LineWidth', 1 );
plot(vGprTe(:,1), vGprTe(:,3), 'r.-','MarkerSize',3, 'LineWidth', 2 );
legend({'var$[\Delta d]$','GPR$[\Delta d]$'},'interpreter','latex','FontSize',FSize);
ylabel('Var$[m]$','interpreter','latex','FontSize',FSize);
xlabel('$r[m]$','interpreter','latex','FontSize',FSize);
% axis([0 params.MaxR 0 MaxZ]);

subplot(4,4,4);set(gca,'color',[0.3 0.3 0.3]);cla; hold on; grid on;box on;
plot(vGprTr(:,1), vGprTr(:,2),'w+--','MarkerSize',10, 'LineWidth', 1 );
plot(vGprTe(:,1), vGprTe(:,2), 'g.-','MarkerSize',3, 'LineWidth', 2  );
legend({'var$[\Delta d]$','GPR$[\Delta d]$'},'interpreter','latex','FontSize',FSize);
ylabel('Var$[m]$','interpreter','latex','FontSize',FSize);
xlabel('$r[m]$','interpreter','latex','FontSize',FSize);
% axis([0 params.MaxR 0 MaxZ]);

subplot(4,4,13);set(gca,'color',[0.3 0.3 0.3]);cla; hold on; grid on;box on;
plot(vGprTr(:,1), vGprTr(:,4),'w+--','MarkerSize',10, 'LineWidth', 1 );
plot(vGprTe(:,1), vGprTe(:,4), 'b.-','MarkerSize',3, 'LineWidth', 2  );
legend({'var$[\Delta d]$','GPR$[\Delta d]$'},'interpreter','latex','FontSize',FSize);
ylabel('Var$[m]$','interpreter','latex','FontSize',FSize);
xlabel('$r[m]$','interpreter','latex','FontSize',FSize);
% axis([0 params.MaxR 0 MaxZ]);

subplot(4,4,16);set(gca,'color',[0.3 0.3 0.3]);cla; hold on; grid on;box on;
plot(vGprTr(:,1), vGprTr(:,5),'w+--','MarkerSize',10, 'LineWidth', 1 );
plot(vGprTe(:,1), vGprTe(:,5), 'y.-','MarkerSize',3, 'LineWidth', 2  );
legend({'var$[\Delta d]$','GPR$[\Delta d]$'},'interpreter','latex','FontSize',FSize);
ylabel('Var$[m]$','interpreter','latex','FontSize',FSize);
xlabel('$r[m]$','interpreter','latex','FontSize',FSize);
% axis([0 params.MaxR 0 MaxZ]);