function CorresTF = CalCorrespondTF(kdMap, ptMap, ptOrg, XbkTF, ParaS)
InitTransform = affine3d(XbkTF');
if strcmp(ParaS.RegM, 'ICP')
    ptICP = pcdownsample(ptOrg, 'random', 0.03); % about 3000 points
    tform = PointToPlaneICPVer2(ptICP, ptMap, kdMap, 10, InitTransform); % modified at 2020-02-25
    CorresTF = tform.T'; % icp used to find the best correspondences
else  %  Ndt
    ptNdt = pcdownsample(ptOrg, 'random', 0.03); % about 2000 points
    GridRes = 2;         %ptICP ?
    tform = pcregisterndt(ptNdt, ptMap, GridRes, 'InitialTransform', InitTransform, 'OutlierRatio',0.8, 'MaxIterations', 10);
    CorresTF = tform.T';
end
end